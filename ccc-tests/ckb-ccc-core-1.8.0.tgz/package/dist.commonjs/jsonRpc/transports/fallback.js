"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransportFallback = void 0;
class TransportFallback {
    constructor(transports) {
        this.transports = transports;
        // Current transport index
        this.i = 0;
    }
    async request(data) {
        let triedCount = 0;
        while (true) {
            try {
                return await this.transports[this.i % this.transports.length].request(data);
            }
            catch (err) {
                triedCount += 1;
                this.i += 1;
                if (triedCount >= this.transports.length) {
                    throw err;
                }
            }
        }
    }
}
exports.TransportFallback = TransportFallback;
