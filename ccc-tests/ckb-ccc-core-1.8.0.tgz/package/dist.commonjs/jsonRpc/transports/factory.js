"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transportFromUri = transportFromUri;
const http_js_1 = require("./http.js");
const webSocket_js_1 = require("./webSocket.js");
function transportFromUri(uri, config) {
    if (uri.startsWith("wss://") || uri.startsWith("ws://")) {
        return new webSocket_js_1.TransportWebSocket(uri, config?.timeout);
    }
    return new http_js_1.TransportHttp(uri, config?.timeout);
}
