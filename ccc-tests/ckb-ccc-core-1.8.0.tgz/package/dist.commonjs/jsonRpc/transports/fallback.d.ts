import { JsonRpcPayload, Transport } from "./transport.js";
export declare class TransportFallback implements Transport {
    private readonly transports;
    private i;
    constructor(transports: Transport[]);
    request(data: JsonRpcPayload): Promise<unknown>;
}
//# sourceMappingURL=fallback.d.ts.map