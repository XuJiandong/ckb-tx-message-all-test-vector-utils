"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientPublicTestnet = void 0;
const isomorphic_ws_1 = __importDefault(require("isomorphic-ws"));
const clientPublicTestnet_advanced_js_1 = require("./clientPublicTestnet.advanced.js");
const clientTypes_js_1 = require("./clientTypes.js");
const index_js_1 = require("./jsonRpc/index.js");
/**
 * @public
 */
class ClientPublicTestnet extends index_js_1.ClientJsonRpc {
    constructor(config) {
        const hasWebSocket = typeof isomorphic_ws_1.default !== "undefined";
        super(config?.url ??
            (hasWebSocket
                ? "wss://testnet.ckb.dev/ws"
                : "https://testnet.ckb.dev/"), {
            ...config,
            fallbacks: config?.fallbacks ??
                (hasWebSocket
                    ? [
                        "wss://testnet.ckb.dev/ws",
                        "https://testnet.ckb.dev/",
                        "https://testnet.ckbapp.dev/",
                    ]
                    : ["https://testnet.ckb.dev/", "https://testnet.ckbapp.dev/"]),
        });
        this.config = config;
    }
    get scripts() {
        return this.config?.scripts ?? clientPublicTestnet_advanced_js_1.TESTNET_SCRIPTS;
    }
    get addressPrefix() {
        return "ckt";
    }
    async getKnownScript(script) {
        const found = this.scripts[script];
        if (!found) {
            throw new Error(`No script information was found for ${script} on ${this.addressPrefix}`);
        }
        return clientTypes_js_1.ScriptInfo.from(found);
    }
}
exports.ClientPublicTestnet = ClientPublicTestnet;
