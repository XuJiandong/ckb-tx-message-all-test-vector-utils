"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.KnownScript = void 0;
/**
 * @public
 */
var KnownScript;
(function (KnownScript) {
    KnownScript["NervosDao"] = "NervosDao";
    KnownScript["Secp256k1Blake160"] = "Secp256k1Blake160";
    KnownScript["Secp256k1Multisig"] = "Secp256k1Multisig";
    KnownScript["AnyoneCanPay"] = "AnyoneCanPay";
    KnownScript["TypeId"] = "TypeId";
    KnownScript["XUdt"] = "XUdt";
    KnownScript["JoyId"] = "JoyId";
    KnownScript["COTA"] = "COTA";
    KnownScript["PWLock"] = "PWLock";
    KnownScript["OmniLock"] = "OmniLock";
    KnownScript["NostrLock"] = "NostrLock";
    KnownScript["UniqueType"] = "UniqueType";
    // ckb-proxy-locks https://github.com/ckb-devrel/ckb-proxy-locks
    KnownScript["AlwaysSuccess"] = "AlwaysSuccess";
    KnownScript["InputTypeProxyLock"] = "InputTypeProxyLock";
    KnownScript["OutputTypeProxyLock"] = "OutputTypeProxyLock";
    KnownScript["LockProxyLock"] = "LockProxyLock";
    KnownScript["SingleUseLock"] = "SingleUseLock";
    KnownScript["TypeBurnLock"] = "TypeBurnLock";
    KnownScript["EasyToDiscoverType"] = "EasyToDiscoverType";
    KnownScript["TimeLock"] = "TimeLock";
})(KnownScript || (exports.KnownScript = KnownScript = {}));
