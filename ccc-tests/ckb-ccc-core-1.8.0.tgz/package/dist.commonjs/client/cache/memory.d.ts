import { Cell, CellLike, OutPointLike } from "../../ckb/index.js";
import { HexLike } from "../../hex/index.js";
import { NumLike } from "../../num/index.js";
import { ClientCollectableSearchKeyLike } from "../clientTypes.advanced.js";
import { ClientBlock, ClientBlockHeader, ClientBlockHeaderLike, ClientBlockLike, ClientTransactionResponse, ClientTransactionResponseLike } from "../clientTypes.js";
import { ClientCache } from "./cache.js";
export declare class ClientCacheMemory extends ClientCache {
    private readonly maxCells;
    private readonly maxTxs;
    private readonly maxBlocks;
    /**
     * OutPoint => [isLive, Cell | OutPoint]
     */
    private readonly cells;
    /**
     * TX Hash => Transaction Response
     */
    private readonly knownTransactions;
    /**
     * Block Number => Block Hash
     */
    private readonly knownBlockHashes;
    /**
     * Block Hash => Block Header / Full Block
     */
    private readonly knownBlocks;
    constructor(maxCells?: number, maxTxs?: number, maxBlocks?: number);
    markUsableNoCache(...cellLikes: (CellLike | CellLike[])[]): Promise<void>;
    markUnusable(...outPointLikes: (OutPointLike | OutPointLike[])[]): Promise<void>;
    clear(): Promise<void>;
    findCells(keyLike: ClientCollectableSearchKeyLike): AsyncGenerator<Cell>;
    isUnusable(outPointLike: OutPointLike): Promise<boolean>;
    recordCells(...cells: (CellLike | CellLike[])[]): Promise<void>;
    getCell(outPointLike: OutPointLike): Promise<Cell | undefined>;
    recordTransactionResponses(...transactions: (ClientTransactionResponseLike | ClientTransactionResponseLike[])[]): Promise<void>;
    getTransactionResponse(txHashLike: HexLike): Promise<ClientTransactionResponse | undefined>;
    recordHeaders(...headers: (ClientBlockHeaderLike | ClientBlockHeaderLike[])[]): Promise<void>;
    getHeaderByHash(hashLike: HexLike): Promise<ClientBlockHeader | undefined>;
    getHeaderByNumber(numberLike: NumLike): Promise<ClientBlockHeader | undefined>;
    recordBlocks(...blocks: (ClientBlockLike | ClientBlockLike[])[]): Promise<void>;
    getBlockByHash(hashLike: HexLike): Promise<ClientBlock | undefined>;
    getBlockByNumber(numberLike: NumLike): Promise<ClientBlock | undefined>;
}
//# sourceMappingURL=memory.d.ts.map