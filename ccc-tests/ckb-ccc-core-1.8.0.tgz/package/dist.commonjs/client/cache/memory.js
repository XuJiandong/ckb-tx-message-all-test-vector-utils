"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientCacheMemory = void 0;
const index_js_1 = require("../../ckb/index.js");
const index_js_2 = require("../../hex/index.js");
const index_js_3 = require("../../num/index.js");
const clientTypes_js_1 = require("../clientTypes.js");
const cache_js_1 = require("./cache.js");
const memory_advanced_js_1 = require("./memory.advanced.js");
class ClientCacheMemory extends cache_js_1.ClientCache {
    constructor(maxCells = 512, maxTxs = 256, maxBlocks = 128) {
        super();
        this.maxCells = maxCells;
        this.maxTxs = maxTxs;
        this.maxBlocks = maxBlocks;
        this.cells = new memory_advanced_js_1.MapLru(this.maxCells);
        this.knownTransactions = new memory_advanced_js_1.MapLru(this.maxTxs);
        this.knownBlockHashes = new memory_advanced_js_1.MapLru(this.maxBlocks);
        this.knownBlocks = new memory_advanced_js_1.MapLru(this.maxBlocks);
    }
    async markUsableNoCache(...cellLikes) {
        cellLikes.flat().forEach((cellLike) => {
            const cell = index_js_1.Cell.from(cellLike).clone();
            const outPointStr = (0, index_js_2.hexFrom)(cell.outPoint.toBytes());
            this.cells.set(outPointStr, [true, cell]);
        });
    }
    async markUnusable(...outPointLikes) {
        outPointLikes.flat().forEach((outPointLike) => {
            const outPoint = index_js_1.OutPoint.from(outPointLike);
            const outPointStr = (0, index_js_2.hexFrom)(outPoint.toBytes());
            const existed = this.cells.get(outPointStr);
            if (existed) {
                existed[0] = false;
                return;
            }
            this.cells.set(outPointStr, [false, { outPoint }]);
        });
    }
    async clear() {
        this.cells.clear();
        this.knownTransactions.clear();
    }
    async *findCells(keyLike) {
        for (const [key, [isLive, cell]] of this.cells.entries()) {
            if (!isLive) {
                continue;
            }
            if (!(0, memory_advanced_js_1.filterCell)(keyLike, cell)) {
                continue;
            }
            this.cells.get(key);
            yield cell.clone();
        }
    }
    async isUnusable(outPointLike) {
        const outPoint = index_js_1.OutPoint.from(outPointLike);
        return !(this.cells.get((0, index_js_2.hexFrom)(outPoint.toBytes()))?.[0] ?? true);
    }
    async recordCells(...cells) {
        cells.flat().map((cellLike) => {
            const cell = index_js_1.Cell.from(cellLike);
            const outPointStr = (0, index_js_2.hexFrom)(cell.outPoint.toBytes());
            if (this.cells.get(outPointStr)) {
                return;
            }
            this.cells.set(outPointStr, [undefined, cell]);
        });
    }
    async getCell(outPointLike) {
        const outPoint = index_js_1.OutPoint.from(outPointLike);
        const cell = this.cells.get((0, index_js_2.hexFrom)(outPoint.toBytes()))?.[1];
        if (cell && cell.cellOutput && cell.outputData) {
            return index_js_1.Cell.from(cell.clone());
        }
    }
    async recordTransactionResponses(...transactions) {
        transactions.flat().map((txLike) => {
            const tx = clientTypes_js_1.ClientTransactionResponse.from(txLike);
            this.knownTransactions.set(tx.transaction.hash(), tx);
        });
    }
    async getTransactionResponse(txHashLike) {
        const txHash = (0, index_js_2.hexFrom)(txHashLike);
        return this.knownTransactions.get(txHash)?.clone();
    }
    async recordHeaders(...headers) {
        headers.flat().map((headerLike) => {
            const header = clientTypes_js_1.ClientBlockHeader.from(headerLike);
            this.knownBlockHashes.set(header.number, header.hash);
            const existed = this.knownBlocks.get(header.hash);
            if (existed) {
                return;
            }
            this.knownBlocks.set(header.hash, { header });
        });
    }
    async getHeaderByHash(hashLike) {
        const hash = (0, index_js_2.hexFrom)(hashLike);
        const block = this.knownBlocks.get(hash);
        if (block) {
            this.knownBlockHashes.get(block.header.number); // For LRU
        }
        return block?.header;
    }
    async getHeaderByNumber(numberLike) {
        const number = (0, index_js_3.numFrom)(numberLike);
        const hash = this.knownBlockHashes.get(number);
        if (!hash) {
            return;
        }
        return this.getHeaderByHash(hash);
    }
    async recordBlocks(...blocks) {
        blocks.flat().map((blockLike) => {
            const block = clientTypes_js_1.ClientBlock.from(blockLike);
            this.knownBlockHashes.set(block.header.number, block.header.hash);
            this.knownBlocks.set(block.header.hash, block);
        });
    }
    async getBlockByHash(hashLike) {
        const hash = (0, index_js_2.hexFrom)(hashLike);
        const block = this.knownBlocks.get(hash);
        if (block) {
            this.knownBlockHashes.get(block.header.number); // For LRU
            if ("transactions" in block) {
                return block;
            }
        }
        return;
    }
    async getBlockByNumber(numberLike) {
        const number = (0, index_js_3.numFrom)(numberLike);
        const hash = this.knownBlockHashes.get(number);
        if (!hash) {
            return;
        }
        return this.getBlockByHash(hash);
    }
}
exports.ClientCacheMemory = ClientCacheMemory;
