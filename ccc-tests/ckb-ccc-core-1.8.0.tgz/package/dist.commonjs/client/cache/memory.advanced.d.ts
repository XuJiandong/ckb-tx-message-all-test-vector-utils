import { Cell, CellLike, ScriptLike } from "../../ckb/index.js";
import { HexLike } from "../../hex/index.js";
import { NumLike } from "../../num/index.js";
import { ClientCollectableSearchKeyLike } from "../clientTypes.advanced.js";
export type CellRecord = [
    false,
    Pick<Cell, "outPoint"> & Partial<Pick<Cell, "cellOutput" | "outputData">>
] | [true, Cell] | [undefined, Cell];
export declare function filterData(dataLike: HexLike, filterLike: HexLike | undefined, filterMode: "exact" | "prefix" | "partial"): boolean;
export declare function filterScript(valueLike: ScriptLike | undefined, filterLike: ScriptLike | undefined, filterMode: "prefix" | "exact" | "partial"): boolean;
export declare function filterNumByRange(lengthLike: NumLike, range: [NumLike, NumLike] | undefined): boolean;
export declare function filterScriptByLenRange(valueLike?: ScriptLike, scriptLenRange?: [NumLike, NumLike]): boolean;
export declare function filterCell(searchKeyLike: ClientCollectableSearchKeyLike, cellLike: CellLike): boolean;
export declare class MapLru<K, V> extends Map<K, V> {
    private readonly capacity;
    private readonly lru;
    constructor(capacity: number);
    get(key: K): (V & ({} | null)) | undefined;
    set(key: K, value: V): this;
    delete(key: K): boolean;
}
//# sourceMappingURL=memory.advanced.d.ts.map