"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientCache = void 0;
const index_js_1 = require("../../ckb/index.js");
/**
 * @public
 * The ClientCache class is mainly designed for chained transactions.
 * Consumed & Created cells are "marked" so they can be correctly handled when composing transactions.
 * It also act as cache for rpc requests to reduce cost, but this is optional.
 */
class ClientCache {
    async markUsable(...cellLikes) {
        await this.recordCells(...cellLikes);
        return this.markUsableNoCache(...cellLikes);
    }
    async markTransactions(...transactionLike) {
        await Promise.all([
            this.recordTransactionResponses(transactionLike.flat().map((transaction) => ({
                transaction: transaction,
                status: "sent",
            }))),
            ...transactionLike.flat().map((transactionLike) => {
                const tx = index_js_1.Transaction.from(transactionLike);
                const txHash = tx.hash();
                return Promise.all([
                    ...tx.inputs.map((i) => this.markUnusable(i.previousOutput)),
                    ...tx.outputs.map((o, i) => this.markUsable({
                        cellOutput: o,
                        outputData: tx.outputsData[i],
                        outPoint: {
                            txHash,
                            index: i,
                        },
                    })),
                ]);
            }),
        ]);
    }
    // ======
    // Following methods are for requests caching and optional.
    // ======
    /**
     * Record known cells
     * Implement this method to enable cells query caching
     * @param _cells
     */
    async recordCells(..._cells) { }
    /**
     * Get a known cell by out point
     * Implement this method to enable cells query caching
     * @param _outPoint
     */
    async getCell(_outPoint) {
        return;
    }
    /**
     * Record known transaction responses.
     * Implement this method to enable transactions query caching
     * @param _transactions
     */
    async recordTransactionResponses(..._transactions) { }
    /**
     * Get a known transaction response by hash
     * Implement this method to enable transactions query caching
     * @param _txHash
     */
    async getTransactionResponse(_txHash) {
        return;
    }
    /**
     * Record known transactions.
     * @param transactions
     */
    async recordTransactions(...transactions) {
        return this.recordTransactionResponses(transactions.flat().map((transaction) => ({
            transaction,
            status: "unknown",
        })));
    }
    /**
     * Get a known transaction by hash
     * @param txHash
     */
    async getTransaction(txHash) {
        return (await this.getTransactionResponse(txHash))?.transaction;
    }
    /**
     * Record known block headers.
     * Implement this method to enable block headers query caching
     * @param _headers
     */
    async recordHeaders(..._headers) { }
    /**
     * Get a known block header by hash
     * Implement this method to enable block headers query caching
     * @param _hash
     */
    async getHeaderByHash(_hash) {
        return;
    }
    /**
     * Get a known block header by number
     * Implement this method to enable block headers query caching
     * @param _number
     */
    async getHeaderByNumber(_number) {
        return;
    }
    /**
     * Record known blocks.
     * Implement this method to enable blocks query caching
     * @param _blocks
     */
    async recordBlocks(..._blocks) { }
    /**
     * Get a known block header by hash
     * Implement this method to enable block headers query caching
     * @param _hash
     */
    async getBlockByHash(_hash) {
        return;
    }
    /**
     * Get a known block header by number
     * Implement this method to enable block headers query caching
     * @param _number
     */
    async getBlockByNumber(_number) {
        return;
    }
}
exports.ClientCache = ClientCache;
