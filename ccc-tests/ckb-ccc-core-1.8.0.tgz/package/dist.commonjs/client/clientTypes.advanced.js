"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_MIN_FEE_RATE = exports.DEFAULT_MAX_FEE_RATE = exports.CONFIRMED_BLOCK_TIME = void 0;
exports.clientSearchKeyRangeFrom = clientSearchKeyRangeFrom;
const index_js_1 = require("../num/index.js");
exports.CONFIRMED_BLOCK_TIME = (0, index_js_1.numFrom)(1000 * 10 * 50); // 50 blocks * 10s
exports.DEFAULT_MAX_FEE_RATE = (0, index_js_1.numFrom)(10000000);
exports.DEFAULT_MIN_FEE_RATE = (0, index_js_1.numFrom)(1000);
function clientSearchKeyRangeFrom([a, b]) {
    return [(0, index_js_1.numFrom)(a), (0, index_js_1.numFrom)(b)];
}
