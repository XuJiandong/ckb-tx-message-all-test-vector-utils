"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorClientMaxFeeRateExceeded = exports.ErrorClientWaitTransactionTimeout = exports.ErrorClientRBFRejected = exports.ErrorClientDuplicatedTransaction = exports.ErrorClientVerification = exports.ErrorClientResolveUnknown = exports.ErrorClientBase = exports.ClientBlock = exports.ClientBlockUncle = exports.ClientBlockHeader = exports.ClientIndexerSearchKeyTransaction = exports.ClientIndexerSearchKey = exports.ClientIndexerSearchKeyFilter = exports.ClientTransactionResponse = exports.ScriptInfo = exports.CellDepInfo = void 0;
const index_js_1 = require("../ckb/index.js");
const index_js_2 = require("../hex/index.js");
const index_js_3 = require("../num/index.js");
const index_js_4 = require("../utils/index.js");
const clientTypes_advanced_js_1 = require("./clientTypes.advanced.js");
/**
 * @public
 */
class CellDepInfo {
    constructor(cellDep, type) {
        this.cellDep = cellDep;
        this.type = type;
    }
    static from(cellDepInfoLike) {
        if (cellDepInfoLike instanceof CellDepInfo) {
            return cellDepInfoLike;
        }
        return new CellDepInfo(index_js_1.CellDep.from(cellDepInfoLike.cellDep), (0, index_js_4.apply)(index_js_1.Script.from, cellDepInfoLike.type));
    }
}
exports.CellDepInfo = CellDepInfo;
/**
 * @public
 */
class ScriptInfo {
    constructor(codeHash, hashType, cellDeps) {
        this.codeHash = codeHash;
        this.hashType = hashType;
        this.cellDeps = cellDeps;
    }
    static from(scriptInfoLike) {
        if (scriptInfoLike instanceof ScriptInfo) {
            return scriptInfoLike;
        }
        return new ScriptInfo((0, index_js_2.hexFrom)(scriptInfoLike.codeHash), (0, index_js_1.hashTypeFrom)(scriptInfoLike.hashType), scriptInfoLike.cellDeps.map((c) => CellDepInfo.from(c)));
    }
}
exports.ScriptInfo = ScriptInfo;
/**
 * @public
 */
class ClientTransactionResponse {
    constructor(transaction, status, cycles, blockHash, blockNumber, txIndex, reason) {
        this.transaction = transaction;
        this.status = status;
        this.cycles = cycles;
        this.blockHash = blockHash;
        this.blockNumber = blockNumber;
        this.txIndex = txIndex;
        this.reason = reason;
    }
    static from(responseLike) {
        if (responseLike instanceof ClientTransactionResponse) {
            return responseLike;
        }
        return new ClientTransactionResponse(index_js_1.Transaction.from(responseLike.transaction), responseLike.status, (0, index_js_4.apply)(index_js_3.numFrom, responseLike.cycles), (0, index_js_4.apply)(index_js_2.hexFrom, responseLike.blockHash), (0, index_js_4.apply)(index_js_3.numFrom, responseLike.blockNumber), (0, index_js_4.apply)(index_js_3.numFrom, responseLike.txIndex), responseLike.reason);
    }
    clone() {
        return new ClientTransactionResponse(this.transaction.clone(), this.status, this.cycles, this.blockHash, this.blockNumber, this.txIndex, this.reason);
    }
}
exports.ClientTransactionResponse = ClientTransactionResponse;
/**
 * @public
 */
class ClientIndexerSearchKeyFilter {
    constructor(script, scriptLenRange, outputData, outputDataSearchMode, outputDataLenRange, outputCapacityRange, blockRange) {
        this.script = script;
        this.scriptLenRange = scriptLenRange;
        this.outputData = outputData;
        this.outputDataSearchMode = outputDataSearchMode;
        this.outputDataLenRange = outputDataLenRange;
        this.outputCapacityRange = outputCapacityRange;
        this.blockRange = blockRange;
    }
    static from(filterLike) {
        if (filterLike instanceof ClientIndexerSearchKeyFilter) {
            return filterLike;
        }
        return new ClientIndexerSearchKeyFilter((0, index_js_4.apply)(index_js_1.Script.from, filterLike.script), (0, index_js_4.apply)(clientTypes_advanced_js_1.clientSearchKeyRangeFrom, filterLike.scriptLenRange), (0, index_js_4.apply)(index_js_2.hexFrom, filterLike.outputData), filterLike.outputDataSearchMode ?? undefined, (0, index_js_4.apply)(clientTypes_advanced_js_1.clientSearchKeyRangeFrom, filterLike.outputDataLenRange), (0, index_js_4.apply)(clientTypes_advanced_js_1.clientSearchKeyRangeFrom, filterLike.outputCapacityRange), (0, index_js_4.apply)(clientTypes_advanced_js_1.clientSearchKeyRangeFrom, filterLike.blockRange));
    }
}
exports.ClientIndexerSearchKeyFilter = ClientIndexerSearchKeyFilter;
/**
 * @public
 */
class ClientIndexerSearchKey {
    constructor(script, scriptType, scriptSearchMode, filter, withData) {
        this.script = script;
        this.scriptType = scriptType;
        this.scriptSearchMode = scriptSearchMode;
        this.filter = filter;
        this.withData = withData;
    }
    static from(keyLike) {
        if (keyLike instanceof ClientIndexerSearchKey) {
            return keyLike;
        }
        return new ClientIndexerSearchKey(index_js_1.Script.from(keyLike.script), keyLike.scriptType, keyLike.scriptSearchMode, (0, index_js_4.apply)(ClientIndexerSearchKeyFilter.from, keyLike.filter), keyLike.withData ?? undefined);
    }
}
exports.ClientIndexerSearchKey = ClientIndexerSearchKey;
/**
 * @public
 */
class ClientIndexerSearchKeyTransaction {
    constructor(script, scriptType, scriptSearchMode, filter, groupByTransaction) {
        this.script = script;
        this.scriptType = scriptType;
        this.scriptSearchMode = scriptSearchMode;
        this.filter = filter;
        this.groupByTransaction = groupByTransaction;
    }
    static from(keyLike) {
        if (keyLike instanceof ClientIndexerSearchKeyTransaction) {
            return keyLike;
        }
        return new ClientIndexerSearchKeyTransaction(index_js_1.Script.from(keyLike.script), keyLike.scriptType, keyLike.scriptSearchMode, (0, index_js_4.apply)(ClientIndexerSearchKeyFilter.from, keyLike.filter), keyLike.groupByTransaction ?? undefined);
    }
}
exports.ClientIndexerSearchKeyTransaction = ClientIndexerSearchKeyTransaction;
/**
 * @public
 */
class ClientBlockHeader {
    constructor(compactTarget, dao, epoch, extraHash, hash, nonce, number, parentHash, proposalsHash, timestamp, transactionsRoot, version) {
        this.compactTarget = compactTarget;
        this.dao = dao;
        this.epoch = epoch;
        this.extraHash = extraHash;
        this.hash = hash;
        this.nonce = nonce;
        this.number = number;
        this.parentHash = parentHash;
        this.proposalsHash = proposalsHash;
        this.timestamp = timestamp;
        this.transactionsRoot = transactionsRoot;
        this.version = version;
    }
    static from(headerLike) {
        if (headerLike instanceof ClientBlockHeader) {
            return headerLike;
        }
        return new ClientBlockHeader((0, index_js_3.numFrom)(headerLike.compactTarget), {
            c: (0, index_js_3.numFrom)(headerLike.dao.c),
            ar: (0, index_js_3.numFrom)(headerLike.dao.ar),
            s: (0, index_js_3.numFrom)(headerLike.dao.s),
            u: (0, index_js_3.numFrom)(headerLike.dao.u),
        }, (0, index_js_1.epochFrom)(headerLike.epoch), (0, index_js_2.hexFrom)(headerLike.extraHash), (0, index_js_2.hexFrom)(headerLike.hash), (0, index_js_3.numFrom)(headerLike.nonce), (0, index_js_3.numFrom)(headerLike.number), (0, index_js_2.hexFrom)(headerLike.parentHash), (0, index_js_2.hexFrom)(headerLike.proposalsHash), (0, index_js_3.numFrom)(headerLike.timestamp), (0, index_js_2.hexFrom)(headerLike.transactionsRoot), (0, index_js_3.numFrom)(headerLike.version));
    }
}
exports.ClientBlockHeader = ClientBlockHeader;
/**
 * @public
 */
class ClientBlockUncle {
    constructor(header, proposals) {
        this.header = header;
        this.proposals = proposals;
    }
    static from(uncleLike) {
        if (uncleLike instanceof ClientBlockUncle) {
            return uncleLike;
        }
        return new ClientBlockUncle(ClientBlockHeader.from(uncleLike.header), uncleLike.proposals.map(index_js_2.hexFrom));
    }
}
exports.ClientBlockUncle = ClientBlockUncle;
/**
 * @public
 */
class ClientBlock {
    constructor(header, proposals, transactions, uncles) {
        this.header = header;
        this.proposals = proposals;
        this.transactions = transactions;
        this.uncles = uncles;
    }
    static from(blockLike) {
        if (blockLike instanceof ClientBlock) {
            return blockLike;
        }
        return new ClientBlock(ClientBlockHeader.from(blockLike.header), blockLike.proposals.map(index_js_2.hexFrom), blockLike.transactions.map(index_js_1.Transaction.from), blockLike.uncles.map(ClientBlockUncle.from));
    }
}
exports.ClientBlock = ClientBlock;
class ErrorClientBase extends Error {
    constructor(origin) {
        super(`Client request error ${origin.message}`);
        this.code = origin.code;
        this.data = origin.data;
    }
}
exports.ErrorClientBase = ErrorClientBase;
class ErrorClientResolveUnknown extends ErrorClientBase {
    constructor(origin, outPointLike) {
        super(origin);
        this.outPoint = index_js_1.OutPoint.from(outPointLike);
    }
}
exports.ErrorClientResolveUnknown = ErrorClientResolveUnknown;
class ErrorClientVerification extends ErrorClientBase {
    constructor(origin, source, sourceIndex, errorCode, scriptHashType, scriptCodeHash) {
        super(origin);
        this.source = source;
        this.errorCode = errorCode;
        this.scriptHashType = scriptHashType;
        this.sourceIndex = (0, index_js_3.numFrom)(sourceIndex);
        this.scriptCodeHash = (0, index_js_2.hexFrom)(scriptCodeHash);
    }
}
exports.ErrorClientVerification = ErrorClientVerification;
class ErrorClientDuplicatedTransaction extends ErrorClientBase {
    constructor(origin, txHash) {
        super(origin);
        this.txHash = (0, index_js_2.hexFrom)(txHash);
    }
}
exports.ErrorClientDuplicatedTransaction = ErrorClientDuplicatedTransaction;
class ErrorClientRBFRejected extends ErrorClientBase {
    constructor(origin, currentFee, leastFee) {
        super(origin);
        this.currentFee = (0, index_js_3.numFrom)(currentFee);
        this.leastFee = (0, index_js_3.numFrom)(leastFee);
    }
}
exports.ErrorClientRBFRejected = ErrorClientRBFRejected;
class ErrorClientWaitTransactionTimeout extends ErrorClientBase {
    constructor(timeoutLike) {
        const timeout = (0, index_js_3.numFrom)(timeoutLike).toString();
        super({
            message: `Wait transaction timeout ${timeout}ms`,
            data: JSON.stringify({ timeout }),
        });
    }
}
exports.ErrorClientWaitTransactionTimeout = ErrorClientWaitTransactionTimeout;
class ErrorClientMaxFeeRateExceeded extends ErrorClientBase {
    constructor(limitLike, actualLike) {
        const limit = (0, index_js_3.numFrom)(limitLike).toString();
        const actual = (0, index_js_3.numFrom)(actualLike).toString();
        super({
            message: `Max fee rate exceeded limit ${limit}, actual ${actual}. Developer might forgot to complete transaction fee before sending. See https://api.ckbccc.com/classes/_ckb_ccc_core.index.ccc.Transaction.html#completeFeeBy.`,
            data: JSON.stringify({ limit, actual }),
        });
    }
}
exports.ErrorClientMaxFeeRateExceeded = ErrorClientMaxFeeRateExceeded;
