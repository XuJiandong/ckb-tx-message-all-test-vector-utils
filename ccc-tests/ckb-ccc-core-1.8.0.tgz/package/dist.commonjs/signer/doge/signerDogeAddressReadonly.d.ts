import { Client } from "../../client/index.js";
import { SignerDoge } from "./signerDoge.js";
/**
 * A class extending SignerDoge that provides read-only access to a Doge address.
 * This class does not support signing operations.
 * @public
 */
export declare class SignerDogeAddressReadonly extends SignerDoge {
    private readonly address;
    /**
     * Creates an instance of SignerDogeAddressReadonly.
     *
     * @param client - The client instance used for communication.
     * @param address - The Doge address with the signer.
     */
    constructor(client: Client, address: string);
    /**
     * Connects to the client. This implementation does nothing as the class is read-only.
     *
     * @returns A promise that resolves when the connection is complete.
     */
    connect(): Promise<void>;
    /**
     * Check if the signer is connected.
     *
     * @returns A promise that resolves the connection status.
     */
    isConnected(): Promise<boolean>;
    /**
     * Gets the Doge address associated with the signer.
     *
     * @returns A promise that resolves to a string representing the Doge address.
     *
     * @example
     * ```typescript
     * const account = await signer.getDogeAddress(); // Outputs the Doge address
     * ```
     */
    getDogeAddress(): Promise<string>;
}
//# sourceMappingURL=signerDogeAddressReadonly.d.ts.map