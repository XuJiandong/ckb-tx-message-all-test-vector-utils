"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SignerDoge = void 0;
const bs58check_1 = __importDefault(require("bs58check"));
const index_js_1 = require("../../address/index.js");
const index_js_2 = require("../../bytes/index.js");
const index_js_3 = require("../../ckb/index.js");
const index_js_4 = require("../../client/index.js");
const index_js_5 = require("../../hex/index.js");
const index_js_6 = require("../../num/index.js");
const index_js_7 = require("../signer/index.js");
/**
 * An abstract class extending the Signer class for Dogecoin-like signing operations.
 * This class provides methods to get Doge account, public key, and internal address,
 * as well as signing transactions.
 * @public
 */
class SignerDoge extends index_js_7.Signer {
    get type() {
        return index_js_7.SignerType.Doge;
    }
    get signType() {
        return index_js_7.SignerSignType.DogeEcdsa;
    }
    /**
     * Gets the internal address, which is the Doge account in this case.
     *
     * @returns A promise that resolves to a string representing the internal address.
     */
    async getInternalAddress() {
        return this.getDogeAddress();
    }
    /**
     * Gets the identity, which is the Doge address in this case.
     *
     * @returns A promise that resolves to a string representing the identity
     */
    async getIdentity() {
        return this.getDogeAddress();
    }
    /**
     * Gets an array of Address objects representing the known script addresses for the signer.
     *
     * @returns A promise that resolves to an array of Address objects.
     */
    async getAddressObjs() {
        const hash = bs58check_1.default.decode(await this.getDogeAddress()).slice(1);
        return [
            await index_js_1.Address.fromKnownScript(this.client, index_js_4.KnownScript.OmniLock, (0, index_js_5.hexFrom)([0x05, ...hash, 0x00])),
        ];
    }
    /**
     * prepare a transaction before signing. This method is not implemented and should be overridden by subclasses.
     *
     * @param txLike - The transaction to prepare, represented as a TransactionLike object.
     * @returns A promise that resolves to the prepared Transaction object.
     */
    async prepareTransaction(txLike) {
        const tx = index_js_3.Transaction.from(txLike);
        const { script } = await this.getRecommendedAddressObj();
        await tx.addCellDepsOfKnownScripts(this.client, index_js_4.KnownScript.OmniLock);
        await tx.prepareSighashAllWitness(script, 85, this.client);
        return tx;
    }
    /**
     * Signs a transaction without modifying it.
     *
     * @param txLike - The transaction to sign, represented as a TransactionLike object.
     * @returns A promise that resolves to a signed Transaction object.
     */
    async signOnlyTransaction(txLike) {
        const tx = index_js_3.Transaction.from(txLike);
        const { script } = await this.getRecommendedAddressObj();
        const info = await tx.getSignHashInfo(script, this.client);
        if (!info) {
            return tx;
        }
        const signature = (0, index_js_2.bytesFrom)(await this.signMessageRaw(info.message.slice(2)), "base64");
        signature[0] = 31 + ((signature[0] - 27) % 4);
        const witness = index_js_3.WitnessArgs.fromBytes(tx.witnesses[info.position]);
        witness.lock = (0, index_js_5.hexFrom)((0, index_js_2.bytesConcat)((0, index_js_6.numToBytes)(5 * 4 + signature.length, 4), (0, index_js_6.numToBytes)(4 * 4, 4), (0, index_js_6.numToBytes)(5 * 4 + signature.length, 4), (0, index_js_6.numToBytes)(5 * 4 + signature.length, 4), (0, index_js_6.numToBytes)(signature.length, 4), signature));
        tx.setWitnessArgsAt(info.position, witness);
        return tx;
    }
}
exports.SignerDoge = SignerDoge;
