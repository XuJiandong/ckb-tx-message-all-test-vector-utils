"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyMessageDogeEcdsa = verifyMessageDogeEcdsa;
const secp256k1_1 = require("@noble/curves/secp256k1");
const bitcoinjs_message_1 = require("bitcoinjs-message");
const index_js_1 = require("../../bytes/index.js");
const index_js_2 = require("../../hex/index.js");
const verify_js_1 = require("../btc/verify.js");
/**
 * @public
 */
function verifyMessageDogeEcdsa(message, signature, address) {
    const challenge = typeof message === "string" ? message : (0, index_js_2.hexFrom)(message).slice(2);
    const signatureBytes = (0, index_js_1.bytesFrom)(signature, "base64");
    const recoveryBit = signatureBytes[0];
    const rawSign = signatureBytes.slice(1);
    const sig = secp256k1_1.secp256k1.Signature.fromCompact((0, index_js_2.hexFrom)(rawSign).slice(2)).addRecoveryBit(recoveryBit - 31);
    return ((0, verify_js_1.btcPublicKeyFromP2pkhAddress)(address) ===
        (0, index_js_2.hexFrom)((0, verify_js_1.btcEcdsaPublicKeyHash)(sig
            .recoverPublicKey((0, bitcoinjs_message_1.magicHash)(challenge, "\x19Dogecoin Signed Message:\n"))
            .toHex())));
}
