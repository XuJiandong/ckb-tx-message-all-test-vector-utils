import { BytesLike } from "../../bytes/index.js";
import { Client } from "../../client/index.js";
import { Hex } from "../../hex/index.js";
import { SignerDoge } from "./signerDoge.js";
/**
 * A class extending SignerDoge that provides access to a Doge address.
 * @public
 */
export declare class SignerDogePrivateKey extends SignerDoge {
    readonly dogeNetwork: number;
    private readonly privateKey;
    /**
     * Creates an instance of SignerDogePrivateKey
     *
     * @param client - The client instance used for communication.
     * @param privateKey - The Doge private key with the signer.
     */
    constructor(client: Client, privateKey: BytesLike, dogeNetwork?: number);
    /**
     * Connects to the client. This implementation does nothing as the class is always connected.
     *
     * @returns A promise that resolves when the connection is complete.
     */
    connect(): Promise<void>;
    /**
     * Check if the signer is connected.
     *
     * @returns A promise that resolves the connection status.
     */
    isConnected(): Promise<boolean>;
    getDogePublicKey(): Promise<Hex>;
    /**
     * Gets the Doge address associated with the signer.
     *
     * @returns A promise that resolves to a string representing the Doge address.
     *
     * @example
     * ```typescript
     * const account = await signer.getDogeAddress(); // Outputs the Doge address
     * ```
     */
    getDogeAddress(): Promise<string>;
    /**
     * Signs a message and returns signature only.
     *
     * @param msg - The message to sign, as a string or BytesLike object.
     * @returns A promise that resolves to the signature as a string.
     * @throws Will throw an error if not implemented.
     */
    signMessageRaw(msg: string | BytesLike): Promise<string>;
}
//# sourceMappingURL=signerDogePrivateKey.d.ts.map