import { BytesLike } from "../../bytes/index.js";
/**
 * @public
 */
export declare function verifyMessageDogeEcdsa(message: string | BytesLike, signature: string, address: string): boolean;
//# sourceMappingURL=verify.d.ts.map