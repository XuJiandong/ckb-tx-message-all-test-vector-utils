"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SignerNostrPublicKeyReadonly = void 0;
const bech32_1 = require("bech32");
const index_js_1 = require("../../hex/index.js");
const signerNostr_js_1 = require("./signerNostr.js");
/**
 * Signer from Nostr public key
 * Support npub and hex format
 */
class SignerNostrPublicKeyReadonly extends signerNostr_js_1.SignerNostr {
    constructor(client, publicKey) {
        super(client);
        if (typeof publicKey === "string" && publicKey.startsWith("npub")) {
            const { words } = bech32_1.bech32.decode(publicKey);
            this.publicKey = (0, index_js_1.hexFrom)(bech32_1.bech32.fromWords(words));
        }
        else {
            this.publicKey = (0, index_js_1.hexFrom)(publicKey);
        }
    }
    async connect() { }
    async isConnected() {
        return true;
    }
    async getNostrPublicKey() {
        return this.publicKey;
    }
}
exports.SignerNostrPublicKeyReadonly = SignerNostrPublicKeyReadonly;
