"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SignerNostrPrivateKey = void 0;
const secp256k1_1 = require("@noble/curves/secp256k1");
const bech32_1 = require("bech32");
const index_js_1 = require("../../hex/index.js");
const signerNostrPublicKeyReadonly_js_1 = require("./signerNostrPublicKeyReadonly.js");
const verify_js_1 = require("./verify.js");
/**
 * Signer from Nostr private key
 * Support nsec and hex format
 */
class SignerNostrPrivateKey extends signerNostrPublicKeyReadonly_js_1.SignerNostrPublicKeyReadonly {
    constructor(client, privateKeyLike) {
        const privateKey = (() => {
            if (typeof privateKeyLike === "string" &&
                privateKeyLike.startsWith("nsec")) {
                const { words } = bech32_1.bech32.decode(privateKeyLike);
                return (0, index_js_1.hexFrom)(bech32_1.bech32.fromWords(words));
            }
            return (0, index_js_1.hexFrom)(privateKeyLike);
        })();
        super(client, secp256k1_1.schnorr.getPublicKey(privateKey.slice(2)));
        this.privateKey = privateKey;
    }
    async signNostrEvent(event) {
        const pubkey = (await this.getNostrPublicKey()).slice(2);
        const eventHash = (0, verify_js_1.nostrEventHash)({ ...event, pubkey });
        const signature = secp256k1_1.schnorr.sign(eventHash, this.privateKey.slice(2));
        return {
            ...event,
            id: (0, index_js_1.hexFrom)(eventHash).slice(2),
            pubkey,
            sig: (0, index_js_1.hexFrom)(signature).slice(2),
        };
    }
}
exports.SignerNostrPrivateKey = SignerNostrPrivateKey;
