"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.btcEcdsaPublicKeyHash = btcEcdsaPublicKeyHash;
exports.btcP2pkhAddressFromPublicKey = btcP2pkhAddressFromPublicKey;
exports.btcPublicKeyFromP2pkhAddress = btcPublicKeyFromP2pkhAddress;
exports.verifyMessageBtcEcdsa = verifyMessageBtcEcdsa;
const secp256k1_1 = require("@noble/curves/secp256k1");
const ripemd160_1 = require("@noble/hashes/ripemd160");
const sha256_1 = require("@noble/hashes/sha256");
const bitcoinjs_message_1 = require("bitcoinjs-message");
const bs58check_1 = __importDefault(require("bs58check"));
const index_js_1 = require("../../bytes/index.js");
const index_js_2 = require("../../hex/index.js");
/**
 * @public
 */
function btcEcdsaPublicKeyHash(publicKey) {
    return (0, ripemd160_1.ripemd160)((0, sha256_1.sha256)((0, index_js_1.bytesFrom)(publicKey)));
}
/**
 * @public
 */
function btcP2pkhAddressFromPublicKey(publicKey, network) {
    return bs58check_1.default.encode((0, index_js_1.bytesConcat)([network], btcEcdsaPublicKeyHash(publicKey)));
}
/**
 * @public
 */
function btcPublicKeyFromP2pkhAddress(address) {
    return (0, index_js_2.hexFrom)(bs58check_1.default.decode(address).slice(1));
}
/**
 * @public
 */
function verifyMessageBtcEcdsa(message, signature, publicKey) {
    const challenge = typeof message === "string" ? message : (0, index_js_2.hexFrom)(message).slice(2);
    const rawSign = (0, index_js_1.bytesFrom)(signature, "base64").slice(1);
    return secp256k1_1.secp256k1.verify((0, index_js_1.bytesFrom)(rawSign), (0, bitcoinjs_message_1.magicHash)(challenge), publicKey);
}
