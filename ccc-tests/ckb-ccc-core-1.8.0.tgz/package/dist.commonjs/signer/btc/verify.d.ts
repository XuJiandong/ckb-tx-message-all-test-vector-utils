import { Bytes, BytesLike } from "../../bytes/index.js";
import { Hex } from "../../hex/index.js";
/**
 * @public
 */
export declare function btcEcdsaPublicKeyHash(publicKey: BytesLike): Bytes;
/**
 * @public
 */
export declare function btcP2pkhAddressFromPublicKey(publicKey: BytesLike, network: number): string;
/**
 * @public
 */
export declare function btcPublicKeyFromP2pkhAddress(address: string): Hex;
/**
 * @public
 */
export declare function verifyMessageBtcEcdsa(message: string | BytesLike, signature: string, publicKey: string): boolean;
//# sourceMappingURL=verify.d.ts.map