"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Byte32Opt = exports.Byte32 = exports.Byte16Vec = exports.Byte16Opt = exports.Byte16 = exports.Byte8Vec = exports.Byte8Opt = exports.Byte8 = exports.Byte4Vec = exports.Byte4Opt = exports.Byte4 = exports.BoolVec = exports.BoolOpt = exports.Bool = exports.BytesVec = exports.BytesOpt = exports.Bytes = exports.Uint512Vec = exports.Uint512Opt = exports.Uint512 = exports.Uint512BE = exports.Uint512LE = exports.Uint256Vec = exports.Uint256Opt = exports.Uint256 = exports.Uint256BE = exports.Uint256LE = exports.Uint128Vec = exports.Uint128Opt = exports.Uint128 = exports.Uint128BE = exports.Uint128LE = exports.Uint64Vec = exports.Uint64Opt = exports.Uint64 = exports.Uint64BE = exports.Uint64LE = exports.Uint32Vec = exports.Uint32Opt = exports.Uint32 = exports.Uint32BE = exports.Uint32LE = exports.Uint16Vec = exports.Uint16Opt = exports.Uint16 = exports.Uint16BE = exports.Uint16LE = exports.Uint8Vec = exports.Uint8Opt = exports.Uint8 = void 0;
exports.StringOpt = exports.StringVec = exports.String = exports.Byte32Vec = void 0;
const index_js_1 = require("../bytes/index.js");
const index_js_2 = require("../hex/index.js");
const codec_js_1 = require("./codec.js");
exports.Uint8 = (0, codec_js_1.uintNumber)(1, true);
exports.Uint8Opt = (0, codec_js_1.option)(exports.Uint8);
exports.Uint8Vec = (0, codec_js_1.vector)(exports.Uint8);
exports.Uint16LE = (0, codec_js_1.uintNumber)(2, true);
exports.Uint16BE = (0, codec_js_1.uintNumber)(2);
exports.Uint16 = exports.Uint16LE;
exports.Uint16Opt = (0, codec_js_1.option)(exports.Uint16);
exports.Uint16Vec = (0, codec_js_1.vector)(exports.Uint16);
exports.Uint32LE = (0, codec_js_1.uintNumber)(4, true);
exports.Uint32BE = (0, codec_js_1.uintNumber)(4);
exports.Uint32 = exports.Uint32LE;
exports.Uint32Opt = (0, codec_js_1.option)(exports.Uint32);
exports.Uint32Vec = (0, codec_js_1.vector)(exports.Uint32);
exports.Uint64LE = (0, codec_js_1.uint)(8, true);
exports.Uint64BE = (0, codec_js_1.uint)(8);
exports.Uint64 = exports.Uint64LE;
exports.Uint64Opt = (0, codec_js_1.option)(exports.Uint64);
exports.Uint64Vec = (0, codec_js_1.vector)(exports.Uint64);
exports.Uint128LE = (0, codec_js_1.uint)(16, true);
exports.Uint128BE = (0, codec_js_1.uint)(16);
exports.Uint128 = exports.Uint128LE;
exports.Uint128Opt = (0, codec_js_1.option)(exports.Uint128);
exports.Uint128Vec = (0, codec_js_1.vector)(exports.Uint128);
exports.Uint256LE = (0, codec_js_1.uint)(32, true);
exports.Uint256BE = (0, codec_js_1.uint)(32);
exports.Uint256 = exports.Uint256LE;
exports.Uint256Opt = (0, codec_js_1.option)(exports.Uint256);
exports.Uint256Vec = (0, codec_js_1.vector)(exports.Uint256);
exports.Uint512LE = (0, codec_js_1.uint)(64, true);
exports.Uint512BE = (0, codec_js_1.uint)(64);
exports.Uint512 = exports.Uint512LE;
exports.Uint512Opt = (0, codec_js_1.option)(exports.Uint512);
exports.Uint512Vec = (0, codec_js_1.vector)(exports.Uint512);
exports.Bytes = (0, codec_js_1.byteVec)({
    encode: (value) => (0, index_js_1.bytesFrom)(value),
    decode: (buffer) => (0, index_js_2.hexFrom)(buffer),
});
exports.BytesOpt = (0, codec_js_1.option)(exports.Bytes);
exports.BytesVec = (0, codec_js_1.vector)(exports.Bytes);
exports.Bool = codec_js_1.Codec.from({
    byteLength: 1,
    encode: (value) => (0, index_js_1.bytesFrom)(value ? [1] : [0]),
    decode: (buffer) => (0, index_js_1.bytesFrom)(buffer)[0] !== 0,
});
exports.BoolOpt = (0, codec_js_1.option)(exports.Bool);
exports.BoolVec = (0, codec_js_1.vector)(exports.Bool);
exports.Byte4 = codec_js_1.Codec.from({
    byteLength: 4,
    encode: (value) => (0, index_js_1.bytesFrom)(value),
    decode: (buffer) => (0, index_js_2.hexFrom)(buffer),
});
exports.Byte4Opt = (0, codec_js_1.option)(exports.Byte4);
exports.Byte4Vec = (0, codec_js_1.vector)(exports.Byte4);
exports.Byte8 = codec_js_1.Codec.from({
    byteLength: 8,
    encode: (value) => (0, index_js_1.bytesFrom)(value),
    decode: (buffer) => (0, index_js_2.hexFrom)(buffer),
});
exports.Byte8Opt = (0, codec_js_1.option)(exports.Byte8);
exports.Byte8Vec = (0, codec_js_1.vector)(exports.Byte8);
exports.Byte16 = codec_js_1.Codec.from({
    byteLength: 16,
    encode: (value) => (0, index_js_1.bytesFrom)(value),
    decode: (buffer) => (0, index_js_2.hexFrom)(buffer),
});
exports.Byte16Opt = (0, codec_js_1.option)(exports.Byte16);
exports.Byte16Vec = (0, codec_js_1.vector)(exports.Byte16);
exports.Byte32 = codec_js_1.Codec.from({
    byteLength: 32,
    encode: (value) => (0, index_js_1.bytesFrom)(value),
    decode: (buffer) => (0, index_js_2.hexFrom)(buffer),
});
exports.Byte32Opt = (0, codec_js_1.option)(exports.Byte32);
exports.Byte32Vec = (0, codec_js_1.vector)(exports.Byte32);
exports.String = (0, codec_js_1.byteVec)({
    encode: (value) => (0, index_js_1.bytesFrom)(value, "utf8"),
    decode: (buffer) => (0, index_js_1.bytesTo)(buffer, "utf8"),
});
exports.StringVec = (0, codec_js_1.vector)(exports.String);
exports.StringOpt = (0, codec_js_1.option)(exports.String);
