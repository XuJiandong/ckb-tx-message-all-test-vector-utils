"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var OutPoint_1, CellOutput_1, Since_1, CellInput_1, CellDep_1, WitnessArgs_1, Transaction_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.Transaction = exports.RawTransaction = exports.WitnessArgs = exports.CellDepVec = exports.CellDep = exports.CellInputVec = exports.CellInput = exports.Since = exports.Cell = exports.CellOutputVec = exports.CellOutput = exports.OutPoint = exports.DepTypeCodec = void 0;
exports.depTypeFrom = depTypeFrom;
exports.depTypeToBytes = depTypeToBytes;
exports.depTypeFromBytes = depTypeFromBytes;
exports.epochFrom = epochFrom;
exports.epochFromHex = epochFromHex;
exports.epochToHex = epochToHex;
exports.udtBalanceFrom = udtBalanceFrom;
exports.calcDaoProfit = calcDaoProfit;
exports.calcDaoClaimEpoch = calcDaoClaimEpoch;
const index_js_1 = require("../bytes/index.js");
const index_js_2 = require("../client/index.js");
const knownScript_js_1 = require("../client/knownScript.js");
const index_js_3 = require("../fixedPoint/index.js");
const index_js_4 = require("../hasher/index.js");
const index_js_5 = require("../hex/index.js");
const index_js_6 = require("../molecule/index.js");
const index_js_7 = require("../num/index.js");
const index_js_8 = require("../utils/index.js");
const script_js_1 = require("./script.js");
const transaction_advanced_js_1 = require("./transaction.advanced.js");
exports.DepTypeCodec = index_js_6.mol.Codec.from({
    byteLength: 1,
    encode: depTypeToBytes,
    decode: depTypeFromBytes,
});
/**
 * Converts a DepTypeLike value to a DepType.
 * @public
 *
 * @param val - The value to convert, which can be a string, number, or bigint.
 * @returns The corresponding DepType.
 *
 * @throws Will throw an error if the input value is not a valid dep type.
 *
 * @example
 * ```typescript
 * const depType = depTypeFrom(1); // Outputs "code"
 * const depType = depTypeFrom("depGroup"); // Outputs "depGroup"
 * ```
 */
function depTypeFrom(val) {
    const depType = (() => {
        if (typeof val === "number") {
            return transaction_advanced_js_1.NUM_TO_DEP_TYPE[val];
        }
        if (typeof val === "bigint") {
            return transaction_advanced_js_1.NUM_TO_DEP_TYPE[Number(val)];
        }
        return val;
    })();
    if (depType === undefined) {
        throw new Error(`Invalid dep type ${val}`);
    }
    return depType;
}
/**
 * Converts a DepTypeLike value to its corresponding byte representation.
 * @public
 *
 * @param depType - The dep type value to convert.
 * @returns A Uint8Array containing the byte representation of the dep type.
 *
 * @example
 * ```typescript
 * const depTypeBytes = depTypeToBytes("code"); // Outputs Uint8Array [1]
 * ```
 */
function depTypeToBytes(depType) {
    return (0, index_js_1.bytesFrom)([transaction_advanced_js_1.DEP_TYPE_TO_NUM[depTypeFrom(depType)]]);
}
/**
 * Converts a byte-like value to a DepType.
 * @public
 *
 * @param bytes - The byte-like value to convert.
 * @returns The corresponding DepType.
 *
 * @throws Will throw an error if the input bytes do not correspond to a valid dep type.
 *
 * @example
 * ```typescript
 * const depType = depTypeFromBytes(new Uint8Array([1])); // Outputs "code"
 * ```
 */
function depTypeFromBytes(bytes) {
    return transaction_advanced_js_1.NUM_TO_DEP_TYPE[(0, index_js_1.bytesFrom)(bytes)[0]];
}
/**
 * @public
 */
let OutPoint = OutPoint_1 = class OutPoint extends index_js_6.mol.Entity.Base() {
    /**
     * Creates an instance of OutPoint.
     *
     * @param txHash - The transaction hash.
     * @param index - The index of the output in the transaction.
     */
    constructor(txHash, index) {
        super();
        this.txHash = txHash;
        this.index = index;
    }
    /**
     * Creates an OutPoint instance from an OutPointLike object.
     *
     * @param outPoint - An OutPointLike object or an instance of OutPoint.
     * @returns An OutPoint instance.
     *
     * @example
     * ```typescript
     * const outPoint = OutPoint.from({ txHash: "0x...", index: 0 });
     * ```
     */
    static from(outPoint) {
        if (outPoint instanceof OutPoint_1) {
            return outPoint;
        }
        return new OutPoint_1((0, index_js_5.hexFrom)(outPoint.txHash), (0, index_js_7.numFrom)(outPoint.index));
    }
};
exports.OutPoint = OutPoint;
exports.OutPoint = OutPoint = OutPoint_1 = __decorate([
    index_js_6.mol.codec(index_js_6.mol.struct({
        txHash: index_js_6.mol.Byte32,
        index: index_js_6.mol.Uint32,
    }))
], OutPoint);
/**
 * @public
 */
let CellOutput = CellOutput_1 = class CellOutput extends index_js_6.mol.Entity.Base() {
    /**
     * Creates an instance of CellOutput.
     *
     * @param capacity - The capacity of the cell.
     * @param lock - The lock script of the cell.
     * @param type - The optional type script of the cell.
     */
    constructor(capacity, lock, type) {
        super();
        this.capacity = capacity;
        this.lock = lock;
        this.type = type;
    }
    get occupiedSize() {
        return 8 + this.lock.occupiedSize + (this.type?.occupiedSize ?? 0);
    }
    /**
     * Creates a CellOutput instance from a CellOutputLike object.
     *
     * @param cellOutput - A CellOutputLike object or an instance of CellOutput.
     * @returns A CellOutput instance.
     *
     * @example
     * ```typescript
     * const cellOutput = CellOutput.from({
     *   capacity: 1000n,
     *   lock: { codeHash: "0x...", hashType: "type", args: "0x..." },
     *   type: { codeHash: "0x...", hashType: "type", args: "0x..." }
     * });
     * ```
     */
    static from(cellOutput) {
        if (cellOutput instanceof CellOutput_1) {
            return cellOutput;
        }
        return new CellOutput_1((0, index_js_7.numFrom)(cellOutput.capacity), script_js_1.Script.from(cellOutput.lock), (0, index_js_8.apply)(script_js_1.Script.from, cellOutput.type));
    }
};
exports.CellOutput = CellOutput;
exports.CellOutput = CellOutput = CellOutput_1 = __decorate([
    index_js_6.mol.codec(index_js_6.mol.table({
        capacity: index_js_6.mol.Uint64,
        lock: script_js_1.Script,
        type: script_js_1.ScriptOpt,
    }))
], CellOutput);
exports.CellOutputVec = index_js_6.mol.vector(CellOutput);
/**
 * @public
 */
class Cell {
    /**
     * Creates an instance of Cell.
     *
     * @param outPoint - The output point of the cell.
     * @param cellOutput - The cell output of the cell.
     * @param outputData - The output data of the cell.
     */
    constructor(outPoint, cellOutput, outputData) {
        this.outPoint = outPoint;
        this.cellOutput = cellOutput;
        this.outputData = outputData;
    }
    /**
     * Creates a Cell instance from a CellLike object.
     *
     * @param cell - A CellLike object or an instance of Cell.
     * @returns A Cell instance.
     */
    static from(cell) {
        if (cell instanceof Cell) {
            return cell;
        }
        return new Cell(OutPoint.from("outPoint" in cell ? cell.outPoint : cell.previousOutput), CellOutput.from(cell.cellOutput), (0, index_js_5.hexFrom)(cell.outputData));
    }
    get capacityFree() {
        const occupiedSize = (0, index_js_3.fixedPointFrom)(this.cellOutput.occupiedSize + (0, index_js_1.bytesFrom)(this.outputData).length);
        return this.cellOutput.capacity - occupiedSize;
    }
    /**
     * Occupied bytes of a cell on chain
     * It's CellOutput.occupiedSize + bytesFrom(outputData).byteLength
     */
    get occupiedSize() {
        return this.cellOutput.occupiedSize + (0, index_js_1.bytesFrom)(this.outputData).byteLength;
    }
    /**
     * Gets confirmed Nervos DAO profit of a Cell
     * It returns non-zero value only when the cell is in withdrawal phase 2
     * See https://github.com/nervosnetwork/rfcs/blob/master/rfcs/0023-dao-deposit-withdraw/0023-dao-deposit-withdraw.md
     *
     * @param client - A client for searching DAO related headers
     * @returns Profit
     *
     * @example
     * ```typescript
     * const profit = await cell.getDaoProfit(client);
     * ```
     */
    async getDaoProfit(client) {
        if (!(await this.isNervosDao(client, "withdrew"))) {
            return index_js_3.Zero;
        }
        const { depositHeader, withdrawHeader } = await this.getNervosDaoInfo(client);
        if (!withdrawHeader || !depositHeader) {
            throw new Error(`Unable to get headers of a Nervos DAO cell ${this.outPoint.txHash}:${this.outPoint.index.toString()}`);
        }
        return calcDaoProfit(this.capacityFree, depositHeader, withdrawHeader);
    }
    async isNervosDao(client, phase) {
        const { type } = this.cellOutput;
        const daoType = await client.getKnownScript(knownScript_js_1.KnownScript.NervosDao);
        if (!type ||
            type.codeHash !== daoType.codeHash ||
            type.hashType !== daoType.hashType) {
            // Non Nervos DAO cell
            return false;
        }
        const hasWithdrew = (0, index_js_7.numFrom)(this.outputData) !== index_js_3.Zero;
        return (!phase ||
            (phase === "deposited" && !hasWithdrew) ||
            (phase === "withdrew" && hasWithdrew));
    }
    async getNervosDaoInfo(client) {
        if (!(await this.isNervosDao(client))) {
            // Non Nervos DAO cell
            return {};
        }
        if ((0, index_js_7.numFrom)(this.outputData) === index_js_3.Zero) {
            // Deposited Nervos DAO cell
            const depositRes = await client.getCellWithHeader(this.outPoint);
            if (!depositRes?.header) {
                throw new Error(`Unable to get header of a Nervos DAO deposited cell ${this.outPoint.txHash}:${this.outPoint.index.toString()}`);
            }
            return {
                depositHeader: depositRes.header,
            };
        }
        // Withdrew Nervos DAO cell
        const [depositHeader, withdrawRes] = await Promise.all([
            client.getHeaderByNumber((0, index_js_7.numFromBytes)(this.outputData)),
            client.getCellWithHeader(this.outPoint),
        ]);
        if (!withdrawRes?.header || !depositHeader) {
            throw new Error(`Unable to get headers of a Nervos DAO withdrew cell ${this.outPoint.txHash}:${this.outPoint.index.toString()}`);
        }
        return {
            depositHeader,
            withdrawHeader: withdrawRes.header,
        };
    }
    /**
     * Clone a Cell
     *
     * @returns A cloned Cell instance.
     *
     * @example
     * ```typescript
     * const cell1 = cell0.clone();
     * ```
     */
    clone() {
        return new Cell(this.outPoint.clone(), this.cellOutput.clone(), this.outputData);
    }
}
exports.Cell = Cell;
/**
 * @public
 */
function epochFrom(epochLike) {
    return [(0, index_js_7.numFrom)(epochLike[0]), (0, index_js_7.numFrom)(epochLike[1]), (0, index_js_7.numFrom)(epochLike[2])];
}
/**
 * @public
 */
function epochFromHex(hex) {
    const num = (0, index_js_7.numFrom)((0, index_js_5.hexFrom)(hex));
    return [
        num & (0, index_js_7.numFrom)("0xffffff"),
        (num >> (0, index_js_7.numFrom)(24)) & (0, index_js_7.numFrom)("0xffff"),
        (num >> (0, index_js_7.numFrom)(40)) & (0, index_js_7.numFrom)("0xffff"),
    ];
}
/**
 * @public
 */
function epochToHex(epochLike) {
    const epoch = epochFrom(epochLike);
    return (0, index_js_7.numToHex)((0, index_js_7.numFrom)(epoch[0]) +
        ((0, index_js_7.numFrom)(epoch[1]) << (0, index_js_7.numFrom)(24)) +
        ((0, index_js_7.numFrom)(epoch[2]) << (0, index_js_7.numFrom)(40)));
}
/**
 * @public
 */
let Since = Since_1 = class Since extends index_js_6.mol.Entity.Base() {
    /**
     * Creates an instance of Since.
     *
     * @param relative - Absolute or relative
     * @param metric - The metric of since
     * @param value - The value of since
     */
    constructor(relative, metric, value) {
        super();
        this.relative = relative;
        this.metric = metric;
        this.value = value;
    }
    /**
     * Clone a Since.
     *
     * @returns A cloned Since instance.
     *
     * @example
     * ```typescript
     * const since1 = since0.clone();
     * ```
     */
    clone() {
        return new Since_1(this.relative, this.metric, this.value);
    }
    /**
     * Creates a Since instance from a SinceLike object.
     *
     * @param since - A SinceLike object or an instance of Since.
     * @returns A Since instance.
     *
     * @example
     * ```typescript
     * const since = Since.from("0x1234567812345678");
     * ```
     */
    static from(since) {
        if (since instanceof Since_1) {
            return since;
        }
        if (typeof since === "object" && "relative" in since) {
            return new Since_1(since.relative, since.metric, (0, index_js_7.numFrom)(since.value));
        }
        return Since_1.fromNum(since);
    }
    /**
     * Converts the Since instance to num.
     *
     * @returns A num
     *
     * @example
     * ```typescript
     * const num = since.toNum();
     * ```
     */
    toNum() {
        return (this.value |
            (this.relative === "absolute" ? index_js_3.Zero : (0, index_js_7.numFrom)("0x8000000000000000")) |
            {
                blockNumber: (0, index_js_7.numFrom)("0x0000000000000000"),
                epoch: (0, index_js_7.numFrom)("0x2000000000000000"),
                timestamp: (0, index_js_7.numFrom)("0x4000000000000000"),
            }[this.metric]);
    }
    /**
     * Creates a Since instance from a num-like value.
     *
     * @param numLike - The num-like value to convert.
     * @returns A Since instance.
     *
     * @example
     * ```typescript
     * const since = Since.fromNum("0x0");
     * ```
     */
    static fromNum(numLike) {
        const num = (0, index_js_7.numFrom)(numLike);
        const relative = num >> (0, index_js_7.numFrom)(63) === index_js_3.Zero ? "absolute" : "relative";
        const metric = ["blockNumber", "epoch", "timestamp"][Number((num >> (0, index_js_7.numFrom)(61)) & (0, index_js_7.numFrom)(3))];
        const value = num & (0, index_js_7.numFrom)("0x00ffffffffffffff");
        return new Since_1(relative, metric, value);
    }
};
exports.Since = Since;
exports.Since = Since = Since_1 = __decorate([
    index_js_6.mol.codec(index_js_6.mol.Uint64.mapIn((encodable) => Since.from(encodable).toNum()))
], Since);
/**
 * @public
 */
let CellInput = CellInput_1 = class CellInput extends index_js_6.mol.Entity.Base() {
    /**
     * Creates an instance of CellInput.
     *
     * @param previousOutput - The previous outpoint of the cell.
     * @param since - The since value of the cell input.
     * @param cellOutput - The optional cell output associated with the cell input.
     * @param outputData - The optional output data associated with the cell input.
     */
    constructor(previousOutput, since, cellOutput, outputData) {
        super();
        this.previousOutput = previousOutput;
        this.since = since;
        this.cellOutput = cellOutput;
        this.outputData = outputData;
    }
    /**
     * Creates a CellInput instance from a CellInputLike object.
     *
     * @param cellInput - A CellInputLike object or an instance of CellInput.
     * @returns A CellInput instance.
     *
     * @example
     * ```typescript
     * const cellInput = CellInput.from({
     *   previousOutput: { txHash: "0x...", index: 0 },
     *   since: 0n
     * });
     * ```
     */
    static from(cellInput) {
        if (cellInput instanceof CellInput_1) {
            return cellInput;
        }
        return new CellInput_1(OutPoint.from("previousOutput" in cellInput
            ? cellInput.previousOutput
            : cellInput.outPoint), Since.from(cellInput.since ?? 0).toNum(), (0, index_js_8.apply)(CellOutput.from, cellInput.cellOutput), (0, index_js_8.apply)(index_js_5.hexFrom, cellInput.outputData));
    }
    async getCell(client) {
        await this.completeExtraInfos(client);
        if (!this.cellOutput || !this.outputData) {
            throw new Error("Unable to complete input");
        }
        return Cell.from({
            outPoint: this.previousOutput,
            cellOutput: this.cellOutput,
            outputData: this.outputData,
        });
    }
    /**
     * Complete extra infos in the input. Including
     * - Previous cell output
     * - Previous cell data
     * The instance will be modified.
     *
     * @returns true if succeed.
     * @example
     * ```typescript
     * await cellInput.completeExtraInfos(client);
     * ```
     */
    async completeExtraInfos(client) {
        if (this.cellOutput && this.outputData) {
            return;
        }
        const cell = await client.getCell(this.previousOutput);
        if (!cell) {
            return;
        }
        this.cellOutput = cell.cellOutput;
        this.outputData = cell.outputData;
    }
    /**
     * The extra capacity created when consume this input.
     * This is usually NervosDAO interest, see https://github.com/nervosnetwork/rfcs/blob/master/rfcs/0023-dao-deposit-withdraw/0023-dao-deposit-withdraw.md.
     * And it can also be miners' income. (But this is not implemented yet)
     */
    async getExtraCapacity(client) {
        return (await this.getCell(client)).getDaoProfit(client);
    }
    clone() {
        const cloned = super.clone();
        cloned.cellOutput = this.cellOutput;
        cloned.outputData = this.outputData;
        return cloned;
    }
};
exports.CellInput = CellInput;
exports.CellInput = CellInput = CellInput_1 = __decorate([
    index_js_6.mol.codec(index_js_6.mol
        .struct({
        since: Since,
        previousOutput: OutPoint,
    })
        .mapIn((encodable) => CellInput.from(encodable)))
], CellInput);
exports.CellInputVec = index_js_6.mol.vector(CellInput);
/**
 * @public
 */
let CellDep = CellDep_1 = class CellDep extends index_js_6.mol.Entity.Base() {
    /**
     * Creates an instance of CellDep.
     *
     * @param outPoint - The outpoint of the cell dependency.
     * @param depType - The dependency type.
     */
    constructor(outPoint, depType) {
        super();
        this.outPoint = outPoint;
        this.depType = depType;
    }
    /**
     * Clone a CellDep.
     *
     * @returns A cloned CellDep instance.
     *
     * @example
     * ```typescript
     * const cellDep1 = cellDep0.clone();
     * ```
     */
    clone() {
        return new CellDep_1(this.outPoint.clone(), this.depType);
    }
    /**
     * Creates a CellDep instance from a CellDepLike object.
     *
     * @param cellDep - A CellDepLike object or an instance of CellDep.
     * @returns A CellDep instance.
     *
     * @example
     * ```typescript
     * const cellDep = CellDep.from({
     *   outPoint: { txHash: "0x...", index: 0 },
     *   depType: "depGroup"
     * });
     * ```
     */
    static from(cellDep) {
        if (cellDep instanceof CellDep_1) {
            return cellDep;
        }
        return new CellDep_1(OutPoint.from(cellDep.outPoint), depTypeFrom(cellDep.depType));
    }
};
exports.CellDep = CellDep;
exports.CellDep = CellDep = CellDep_1 = __decorate([
    index_js_6.mol.codec(index_js_6.mol.struct({
        outPoint: OutPoint,
        depType: exports.DepTypeCodec,
    }))
], CellDep);
exports.CellDepVec = index_js_6.mol.vector(CellDep);
/**
 * @public
 */
let WitnessArgs = WitnessArgs_1 = class WitnessArgs extends index_js_6.mol.Entity.Base() {
    /**
     * Creates an instance of WitnessArgs.
     *
     * @param lock - The optional lock field of the witness.
     * @param inputType - The optional input type field of the witness.
     * @param outputType - The optional output type field of the witness.
     */
    constructor(lock, inputType, outputType) {
        super();
        this.lock = lock;
        this.inputType = inputType;
        this.outputType = outputType;
    }
    /**
     * Creates a WitnessArgs instance from a WitnessArgsLike object.
     *
     * @param witnessArgs - A WitnessArgsLike object or an instance of WitnessArgs.
     * @returns A WitnessArgs instance.
     *
     * @example
     * ```typescript
     * const witnessArgs = WitnessArgs.from({
     *   lock: "0x...",
     *   inputType: "0x...",
     *   outputType: "0x..."
     * });
     * ```
     */
    static from(witnessArgs) {
        if (witnessArgs instanceof WitnessArgs_1) {
            return witnessArgs;
        }
        return new WitnessArgs_1((0, index_js_8.apply)(index_js_5.hexFrom, witnessArgs.lock), (0, index_js_8.apply)(index_js_5.hexFrom, witnessArgs.inputType), (0, index_js_8.apply)(index_js_5.hexFrom, witnessArgs.outputType));
    }
};
exports.WitnessArgs = WitnessArgs;
exports.WitnessArgs = WitnessArgs = WitnessArgs_1 = __decorate([
    index_js_6.mol.codec(index_js_6.mol.table({
        lock: index_js_6.mol.BytesOpt,
        inputType: index_js_6.mol.BytesOpt,
        outputType: index_js_6.mol.BytesOpt,
    }))
], WitnessArgs);
/**
 * Convert a bytes to a num.
 *
 * @public
 */
function udtBalanceFrom(dataLike) {
    const data = (0, index_js_1.bytesFrom)(dataLike).slice(0, 16);
    return data.length === 0 ? index_js_3.Zero : (0, index_js_7.numFromBytes)(data);
}
exports.RawTransaction = index_js_6.mol.table({
    version: index_js_6.mol.Uint32,
    cellDeps: exports.CellDepVec,
    headerDeps: index_js_6.mol.Byte32Vec,
    inputs: exports.CellInputVec,
    outputs: exports.CellOutputVec,
    outputsData: index_js_6.mol.BytesVec,
});
/**
 * @public
 */
let Transaction = Transaction_1 = class Transaction extends index_js_6.mol.Entity.Base() {
    /**
     * Creates an instance of Transaction.
     *
     * @param version - The version of the transaction.
     * @param cellDeps - The cell dependencies of the transaction.
     * @param headerDeps - The header dependencies of the transaction.
     * @param inputs - The inputs of the transaction.
     * @param outputs - The outputs of the transaction.
     * @param outputsData - The data associated with the outputs.
     * @param witnesses - The witnesses of the transaction.
     */
    constructor(version, cellDeps, headerDeps, inputs, outputs, outputsData, witnesses) {
        super();
        this.version = version;
        this.cellDeps = cellDeps;
        this.headerDeps = headerDeps;
        this.inputs = inputs;
        this.outputs = outputs;
        this.outputsData = outputsData;
        this.witnesses = witnesses;
    }
    /**
     * Creates a default Transaction instance with empty fields.
     *
     * @returns A default Transaction instance.
     *
     * @example
     * ```typescript
     * const defaultTx = Transaction.default();
     * ```
     */
    static default() {
        return new Transaction_1(0n, [], [], [], [], [], []);
    }
    /**
     * Copy every properties from another transaction.
     *
     * @example
     * ```typescript
     * this.copy(Transaction.default());
     * ```
     */
    copy(txLike) {
        const tx = Transaction_1.from(txLike);
        this.version = tx.version;
        this.cellDeps = tx.cellDeps;
        this.headerDeps = tx.headerDeps;
        this.inputs = tx.inputs;
        this.outputs = tx.outputs;
        this.outputsData = tx.outputsData;
        this.witnesses = tx.witnesses;
    }
    /**
     * Creates a Transaction instance from a TransactionLike object.
     *
     * @param tx - A TransactionLike object or an instance of Transaction.
     * @returns A Transaction instance.
     *
     * @example
     * ```typescript
     * const transaction = Transaction.from({
     *   version: 0,
     *   cellDeps: [],
     *   headerDeps: [],
     *   inputs: [],
     *   outputs: [],
     *   outputsData: [],
     *   witnesses: []
     * });
     * ```
     */
    static from(tx) {
        if (tx instanceof Transaction_1) {
            return tx;
        }
        const outputs = tx.outputs?.map((output, i) => {
            const o = CellOutput.from({
                ...output,
                capacity: output.capacity ?? 0,
            });
            if (o.capacity === index_js_3.Zero) {
                o.capacity = (0, index_js_3.fixedPointFrom)(o.occupiedSize +
                    ((0, index_js_8.apply)(index_js_1.bytesFrom, tx.outputsData?.[i])?.length ?? 0));
            }
            return o;
        }) ?? [];
        const outputsData = outputs.map((_, i) => (0, index_js_5.hexFrom)(tx.outputsData?.[i] ?? "0x"));
        if (tx.outputsData != null && outputsData.length < tx.outputsData.length) {
            outputsData.push(...tx.outputsData.slice(outputsData.length).map((d) => (0, index_js_5.hexFrom)(d)));
        }
        return new Transaction_1((0, index_js_7.numFrom)(tx.version ?? 0), tx.cellDeps?.map((cellDep) => CellDep.from(cellDep)) ?? [], tx.headerDeps?.map(index_js_5.hexFrom) ?? [], tx.inputs?.map((input) => CellInput.from(input)) ?? [], outputs, outputsData, tx.witnesses?.map(index_js_5.hexFrom) ?? []);
    }
    /**
     * Creates a Transaction instance from a Lumos skeleton.
     *
     * @param skeleton - The Lumos transaction skeleton.
     * @returns A Transaction instance.
     *
     * @throws Will throw an error if an input's outPoint is missing.
     *
     * @example
     * ```typescript
     * const transaction = Transaction.fromLumosSkeleton(skeleton);
     * ```
     */
    static fromLumosSkeleton(skeleton) {
        return Transaction_1.from({
            version: 0n,
            cellDeps: skeleton.cellDeps.toArray(),
            headerDeps: skeleton.headerDeps.toArray(),
            inputs: skeleton.inputs.toArray().map((input, i) => {
                if (!input.outPoint) {
                    throw new Error("outPoint is required in input");
                }
                return CellInput.from({
                    previousOutput: input.outPoint,
                    since: skeleton.inputSinces.get(i, "0x0"),
                    cellOutput: input.cellOutput,
                    outputData: input.data,
                });
            }),
            outputs: skeleton.outputs.toArray().map((output) => output.cellOutput),
            outputsData: skeleton.outputs.toArray().map((output) => output.data),
            witnesses: skeleton.witnesses.toArray(),
        });
    }
    /**
     * @deprecated
     * Use ccc.stringify instead.
     * stringify the tx to JSON string.
     */
    stringify() {
        return JSON.stringify(this, (_, value) => {
            if (typeof value === "bigint") {
                return (0, index_js_7.numToHex)(value);
            }
            // eslint-disable-next-line @typescript-eslint/no-unsafe-return
            return value;
        });
    }
    /**
     * Converts the raw transaction data to bytes.
     *
     * @returns A Uint8Array containing the raw transaction bytes.
     *
     * @example
     * ```typescript
     * const rawTxBytes = transaction.rawToBytes();
     * ```
     */
    rawToBytes() {
        return exports.RawTransaction.encode(this);
    }
    /**
     * Calculates the hash of the transaction without witnesses. This is the transaction hash in the usual sense.
     * To calculate the hash of the whole transaction including the witnesses, use transaction.hashFull() instead.
     *
     * @returns The hash of the transaction.
     *
     * @example
     * ```typescript
     * const txHash = transaction.hash();
     * ```
     */
    hash() {
        return (0, index_js_4.hashCkb)(this.rawToBytes());
    }
    /**
     * Calculates the hash of the transaction with witnesses.
     *
     * @returns The hash of the transaction with witnesses.
     *
     * @example
     * ```typescript
     * const txFullHash = transaction.hashFull();
     * ```
     */
    hashFull() {
        return (0, index_js_4.hashCkb)(this.toBytes());
    }
    /**
     * Hashes a witness and updates the hasher.
     *
     * @param witness - The witness to hash.
     * @param hasher - The hasher instance to update.
     *
     * @example
     * ```typescript
     * Transaction.hashWitnessToHasher("0x...", hasher);
     * ```
     */
    static hashWitnessToHasher(witness, hasher) {
        const raw = (0, index_js_1.bytesFrom)((0, index_js_5.hexFrom)(witness));
        hasher.update((0, index_js_7.numToBytes)(raw.length, 8));
        hasher.update(raw);
    }
    static hashBytesToHasher(bytes, hasher) {
        const raw = (0, index_js_1.bytesFrom)((0, index_js_5.hexFrom)(bytes));
        hasher.update((0, index_js_7.numToBytes)(raw.length, 4));
        hasher.update(raw);
    }
    static hashBytesOptToHasher(bytes, hasher) {
        if (bytes) {
            const raw = (0, index_js_1.bytesFrom)((0, index_js_5.hexFrom)(bytes));
            hasher.update((0, index_js_7.numToBytes)(raw.length + 4, 4));
            hasher.update((0, index_js_7.numToBytes)(raw.length, 4));
            hasher.update(raw);
        }
        else {
            hasher.update((0, index_js_7.numToBytes)(0, 4));
        }
    }
    /**
     * Computes the signing hash information for a given script.
     *
     * @param scriptLike - The script associated with the transaction, represented as a ScriptLike object.
     * @param client - The client for complete extra infos in the transaction.
     * @returns A promise that resolves to an object containing the signing message and the witness position,
     *          or undefined if no matching input is found.
     *
     * @example
     * ```typescript
     * const signHashInfo = await tx.getSignHashInfo(scriptLike, client);
     * if (signHashInfo) {
     *   console.log(signHashInfo.message); // Outputs the signing message
     *   console.log(signHashInfo.position); // Outputs the witness position
     * }
     * ```
     */
    async getSignHashInfo(scriptLike, client, hasher = new index_js_4.HasherCkb()) {
        const script = script_js_1.Script.from(scriptLike);
        let position = -1;
        hasher.update(this.hash());
        for (let i = 0; i < this.witnesses.length; i += 1) {
            const input = this.inputs[i];
            if (input) {
                const { cellOutput } = await input.getCell(client);
                if (!script.eq(cellOutput.lock)) {
                    continue;
                }
                if (position === -1) {
                    position = i;
                }
            }
            if (position === -1) {
                return undefined;
            }
            Transaction_1.hashWitnessToHasher(this.witnesses[i], hasher);
        }
        if (position === -1) {
            return undefined;
        }
        return {
            message: hasher.digest(),
            position,
        };
    }
    /**
     * Computes the signing hash information for a given script, specified in the spec:
     * https://github.com/nervosnetwork/rfcs/pull/446
     *
     * @param scriptLike - The script associated with the transaction, represented as a ScriptLike object.
     * @param client - The client for complete extra infos in the transaction.
     * @returns A promise that resolves to an object containing the signing message and the witness position,
     *          or undefined if no matching input is found.
     *
     * @example
     * ```typescript
     * const signHashInfo = await tx.getTxMessageAll(scriptLike, client);
     * if (signHashInfo) {
     *   console.log(signHashInfo.message); // Outputs the signing message
     *   console.log(signHashInfo.position); // Outputs the witness position
     * }
     * ```
     */
    async getTxMessageAll(scriptLike, client, hasher = new index_js_4.HasherCkb()) {
        const script = script_js_1.Script.from(scriptLike);
        let position = -1;
        hasher.update(this.hash());
        for (let i = 0; i < this.inputs.length; i += 1) {
            const { cellOutput, outputData } = await this.inputs[i].getCell(client);
            hasher.update(cellOutput.toBytes());
            Transaction_1.hashBytesToHasher(outputData, hasher);
        }
        for (let i = 0; i < this.witnesses.length; i += 1) {
            const input = this.inputs[i];
            if (input) {
                const { cellOutput } = await input.getCell(client);
                if (!script.eq(cellOutput.lock)) {
                    continue;
                }
                if (position === -1) {
                    position = i;
                }
            }
            if (position === -1) {
                return undefined;
            }
            if (i == position) {
                // the first witness field in current script group
                // The spec requires that:
                // The first witness field of the current running script group, must be a valid WitnessArgs structure serialized
                // in the molecule serialization format, with compatible mode turned off.
                // The molecule in ccc is by default in compatible mode off.
                const witnessArgs = this.getWitnessArgsAt(i);
                Transaction_1.hashBytesOptToHasher(witnessArgs?.inputType, hasher);
                Transaction_1.hashBytesOptToHasher(witnessArgs?.outputType, hasher);
            }
            else {
                // 1. Starting from the second witness field in current script group
                // 2. Starting from the first witness that do not have an input cell of the same index
                Transaction_1.hashBytesToHasher(this.witnesses[i], hasher);
            }
        }
        if (position === -1) {
            return undefined;
        }
        return {
            message: hasher.digest(),
            position,
        };
    }
    /**
     * Find the first occurrence of a input with the specified lock id
     *
     * @param scriptIdLike - The script associated with the transaction, represented as a ScriptLike object without args.
     * @param client - The client for complete extra infos in the transaction.
     * @returns A promise that resolves to the found index
     *
     * @example
     * ```typescript
     * const index = await tx.findInputIndexByLockId(scriptIdLike, client);
     * ```
     */
    async findInputIndexByLockId(scriptIdLike, client) {
        const script = script_js_1.Script.from({ ...scriptIdLike, args: "0x" });
        for (let i = 0; i < this.inputs.length; i += 1) {
            const { cellOutput } = await this.inputs[i].getCell(client);
            if (script.codeHash === cellOutput.lock.codeHash &&
                script.hashType === cellOutput.lock.hashType) {
                return i;
            }
        }
    }
    /**
     * Find the first occurrence of a input with the specified lock
     *
     * @param scriptLike - The script associated with the transaction, represented as a ScriptLike object.
     * @param client - The client for complete extra infos in the transaction.
     * @returns A promise that resolves to the prepared transaction
     *
     * @example
     * ```typescript
     * const index = await tx.findInputIndexByLock(scriptLike, client);
     * ```
     */
    async findInputIndexByLock(scriptLike, client) {
        const script = script_js_1.Script.from(scriptLike);
        for (let i = 0; i < this.inputs.length; i += 1) {
            const { cellOutput } = await this.inputs[i].getCell(client);
            if (script.eq(cellOutput.lock)) {
                return i;
            }
        }
    }
    /**
     * Find the last occurrence of a input with the specified lock
     *
     * @param scriptLike - The script associated with the transaction, represented as a ScriptLike object.
     * @param client - The client for complete extra infos in the transaction.
     * @returns A promise that resolves to the prepared transaction
     *
     * @example
     * ```typescript
     * const index = await tx.findLastInputIndexByLock(scriptLike, client);
     * ```
     */
    async findLastInputIndexByLock(scriptLike, client) {
        const script = script_js_1.Script.from(scriptLike);
        for (let i = this.inputs.length - 1; i >= 0; i -= 1) {
            const { cellOutput } = await this.inputs[i].getCell(client);
            if (script.eq(cellOutput.lock)) {
                return i;
            }
        }
    }
    /**
     * Add cell deps if they are not existed
     *
     * @param cellDepLikes - The cell deps to add
     *
     * @example
     * ```typescript
     * tx.addCellDeps(cellDep);
     * ```
     */
    addCellDeps(...cellDepLikes) {
        cellDepLikes.flat().forEach((cellDepLike) => {
            const cellDep = CellDep.from(cellDepLike);
            if (this.cellDeps.some((c) => c.eq(cellDep))) {
                return;
            }
            this.cellDeps.push(cellDep);
        });
    }
    /**
     * Add cell deps at the start if they are not existed
     *
     * @param cellDepLikes - The cell deps to add
     *
     * @example
     * ```typescript
     * tx.addCellDepsAtBegin(cellDep);
     * ```
     */
    addCellDepsAtStart(...cellDepLikes) {
        cellDepLikes.flat().forEach((cellDepLike) => {
            const cellDep = CellDep.from(cellDepLike);
            if (this.cellDeps.some((c) => c.eq(cellDep))) {
                return;
            }
            this.cellDeps.unshift(cellDep);
        });
    }
    /**
     * Add cell dep from infos if they are not existed
     *
     * @param client - A client for searching cell deps
     * @param cellDepInfoLikes - The cell dep infos to add
     *
     * @example
     * ```typescript
     * tx.addCellDepInfos(client, cellDepInfos);
     * ```
     */
    async addCellDepInfos(client, ...cellDepInfoLikes) {
        this.addCellDeps(await client.getCellDeps(...cellDepInfoLikes));
    }
    /**
     * Add cell deps from known script
     *
     * @param client - The client for searching known script and cell deps
     * @param scripts - The known scripts to add
     *
     * @example
     * ```typescript
     * tx.addCellDepsOfKnownScripts(client, KnownScript.OmniLock);
     * ```
     */
    async addCellDepsOfKnownScripts(client, ...scripts) {
        await Promise.all(scripts
            .flat()
            .map(async (script) => this.addCellDepInfos(client, (await client.getKnownScript(script)).cellDeps)));
    }
    /**
     * Set output data at index.
     *
     * @param index - The index of the output data.
     * @param witness - The data to set.
     *
     * @example
     * ```typescript
     * await tx.setOutputDataAt(0, "0x00");
     * ```
     */
    setOutputDataAt(index, witness) {
        if (this.outputsData.length < index) {
            this.outputsData.push(...Array.from(new Array(index - this.outputsData.length), () => "0x"));
        }
        this.outputsData[index] = (0, index_js_5.hexFrom)(witness);
    }
    /**
     * get input
     *
     * @param index - The cell input index
     *
     * @example
     * ```typescript
     * await tx.getInput(0);
     * ```
     */
    getInput(index) {
        return this.inputs[Number((0, index_js_7.numFrom)(index))];
    }
    /**
     * add input
     *
     * @param inputLike - The cell input.
     *
     * @example
     * ```typescript
     * await tx.addInput({ });
     * ```
     */
    addInput(inputLike) {
        if (this.witnesses.length > this.inputs.length) {
            this.witnesses.splice(this.inputs.length, 0, "0x");
        }
        return this.inputs.push(CellInput.from(inputLike));
    }
    /**
     * get output
     *
     * @param index - The cell output index
     *
     * @example
     * ```typescript
     * await tx.getOutput(0);
     * ```
     */
    getOutput(index) {
        const i = Number((0, index_js_7.numFrom)(index));
        if (i >= this.outputs.length) {
            return;
        }
        return {
            cellOutput: this.outputs[i],
            outputData: this.outputsData[i] ?? "0x",
        };
    }
    /**
     * Add output
     *
     * @param outputLike - The cell output to add
     * @param outputData - optional output data
     *
     * @example
     * ```typescript
     * await tx.addOutput(cellOutput, "0xabcd");
     * ```
     */
    addOutput(outputLike, outputData = "0x") {
        const output = CellOutput.from({
            ...outputLike,
            capacity: outputLike.capacity ?? 0,
        });
        if (output.capacity === index_js_3.Zero) {
            output.capacity = (0, index_js_3.fixedPointFrom)(output.occupiedSize + (0, index_js_1.bytesFrom)(outputData).length);
        }
        const len = this.outputs.push(output);
        this.setOutputDataAt(len - 1, outputData);
        return len;
    }
    /**
     * Get witness at index as WitnessArgs
     *
     * @param index - The index of the witness.
     * @returns The witness parsed as WitnessArgs.
     *
     * @example
     * ```typescript
     * const witnessArgs = await tx.getWitnessArgsAt(0);
     * ```
     */
    getWitnessArgsAt(index) {
        const rawWitness = this.witnesses[index];
        return (rawWitness ?? "0x") !== "0x"
            ? WitnessArgs.fromBytes(rawWitness)
            : undefined;
    }
    /**
     * Set witness at index by WitnessArgs
     *
     * @param index - The index of the witness.
     * @param witness - The WitnessArgs to set.
     *
     * @example
     * ```typescript
     * await tx.setWitnessArgsAt(0, witnessArgs);
     * ```
     */
    setWitnessArgsAt(index, witness) {
        this.setWitnessAt(index, witness.toBytes());
    }
    /**
     * Set witness at index
     *
     * @param index - The index of the witness.
     * @param witness - The witness to set.
     *
     * @example
     * ```typescript
     * await tx.setWitnessAt(0, witness);
     * ```
     */
    setWitnessAt(index, witness) {
        if (this.witnesses.length < index) {
            this.witnesses.push(...Array.from(new Array(index - this.witnesses.length), () => "0x"));
        }
        this.witnesses[index] = (0, index_js_5.hexFrom)(witness);
    }
    /**
     * Prepare dummy witness for sighash all method
     *
     * @param scriptLike - The script associated with the transaction, represented as a ScriptLike object.
     * @param lockLen - The length of dummy lock bytes.
     * @param client - The client for complete extra infos in the transaction.
     * @returns A promise that resolves to the prepared transaction
     *
     * @example
     * ```typescript
     * await tx.prepareSighashAllWitness(scriptLike, 85, client);
     * ```
     */
    async prepareSighashAllWitness(scriptLike, lockLen, client) {
        const position = await this.findInputIndexByLock(scriptLike, client);
        if (position === undefined) {
            return;
        }
        const witness = this.getWitnessArgsAt(position) ?? WitnessArgs.from({});
        witness.lock = (0, index_js_5.hexFrom)(Array.from(new Array(lockLen), () => 0));
        this.setWitnessArgsAt(position, witness);
    }
    async getInputsCapacityExtra(client) {
        return (0, index_js_8.reduceAsync)(this.inputs, async (acc, input) => acc + (await input.getExtraCapacity(client)), (0, index_js_7.numFrom)(0));
    }
    // This also includes extra amount
    async getInputsCapacity(client) {
        return ((await (0, index_js_8.reduceAsync)(this.inputs, async (acc, input) => {
            const { cellOutput: { capacity }, } = await input.getCell(client);
            return acc + capacity;
        }, (0, index_js_7.numFrom)(0))) + (await this.getInputsCapacityExtra(client)));
    }
    getOutputsCapacity() {
        return this.outputs.reduce((acc, { capacity }) => acc + capacity, (0, index_js_7.numFrom)(0));
    }
    async getInputsUdtBalance(client, type) {
        return (0, index_js_8.reduceAsync)(this.inputs, async (acc, input) => {
            const { cellOutput, outputData } = await input.getCell(client);
            if (!cellOutput.type?.eq(type)) {
                return;
            }
            return acc + udtBalanceFrom(outputData);
        }, (0, index_js_7.numFrom)(0));
    }
    getOutputsUdtBalance(type) {
        return this.outputs.reduce((acc, output, i) => {
            if (!output.type?.eq(type)) {
                return acc;
            }
            return acc + udtBalanceFrom(this.outputsData[i]);
        }, (0, index_js_7.numFrom)(0));
    }
    async completeInputs(from, filter, accumulator, init) {
        const collectedCells = [];
        let acc = init;
        let fulfilled = false;
        for await (const cell of from.findCells(filter, true)) {
            if (this.inputs.some(({ previousOutput }) => previousOutput.eq(cell.outPoint))) {
                continue;
            }
            const i = collectedCells.push(cell);
            const next = await Promise.resolve(accumulator(acc, cell, i - 1, collectedCells));
            if (next === undefined) {
                fulfilled = true;
                break;
            }
            acc = next;
        }
        collectedCells.forEach((cell) => this.addInput(cell));
        if (fulfilled) {
            return {
                addedCount: collectedCells.length,
            };
        }
        return {
            addedCount: collectedCells.length,
            accumulated: acc,
        };
    }
    async completeInputsByCapacity(from, capacityTweak, filter) {
        const exceptedCapacity = this.getOutputsCapacity() + (0, index_js_7.numFrom)(capacityTweak ?? 0);
        const inputsCapacity = await this.getInputsCapacity(from.client);
        if (inputsCapacity >= exceptedCapacity) {
            return 0;
        }
        const { addedCount, accumulated } = await this.completeInputs(from, filter ?? {
            scriptLenRange: [0, 1],
            outputDataLenRange: [0, 1],
        }, (acc, { cellOutput: { capacity } }) => {
            const sum = acc + capacity;
            return sum >= exceptedCapacity ? undefined : sum;
        }, inputsCapacity);
        if (accumulated === undefined) {
            return addedCount;
        }
        throw new Error(`Insufficient CKB, need ${(0, index_js_3.fixedPointToString)(exceptedCapacity - accumulated)} extra CKB`);
    }
    async completeInputsAll(from, filter) {
        const { addedCount } = await this.completeInputs(from, filter ?? {
            scriptLenRange: [0, 1],
            outputDataLenRange: [0, 1],
        }, (acc, { cellOutput: { capacity } }) => acc + capacity, index_js_3.Zero);
        return addedCount;
    }
    async completeInputsByUdt(from, type, balanceTweak) {
        const exceptedBalance = this.getOutputsUdtBalance(type) + (0, index_js_7.numFrom)(balanceTweak ?? 0);
        const inputsBalance = await this.getInputsUdtBalance(from.client, type);
        if (inputsBalance >= exceptedBalance) {
            return 0;
        }
        const { addedCount, accumulated } = await this.completeInputs(from, {
            script: type,
            outputDataLenRange: [16, (0, index_js_7.numFrom)("0xffffffff")],
        }, (acc, { outputData }) => {
            const balance = udtBalanceFrom(outputData);
            const sum = acc + balance;
            return sum >= exceptedBalance ? undefined : sum;
        }, inputsBalance);
        if (accumulated === undefined) {
            return addedCount;
        }
        throw new Error(`Insufficient coin, need ${exceptedBalance - accumulated} extra coin`);
    }
    async completeInputsAddOne(from, filter) {
        const { addedCount, accumulated } = await this.completeInputs(from, filter ?? {
            scriptLenRange: [0, 1],
            outputDataLenRange: [0, 1],
        }, () => undefined, true);
        if (accumulated === undefined) {
            return addedCount;
        }
        throw new Error(`Insufficient CKB, need at least one new cell`);
    }
    async completeInputsAtLeastOne(from, filter) {
        if (this.inputs.length > 0) {
            return 0;
        }
        return this.completeInputsAddOne(from, filter);
    }
    async getFee(client) {
        return (await this.getInputsCapacity(client)) - this.getOutputsCapacity();
    }
    async getFeeRate(client) {
        return (((await this.getFee(client)) * (0, index_js_7.numFrom)(1000)) /
            (0, index_js_7.numFrom)(this.toBytes().length + 4));
    }
    estimateFee(feeRate) {
        const txSize = this.toBytes().length + 4;
        // + 999 then / 1000 to ceil the calculated fee
        return ((0, index_js_7.numFrom)(txSize) * (0, index_js_7.numFrom)(feeRate) + (0, index_js_7.numFrom)(999)) / (0, index_js_7.numFrom)(1000);
    }
    async completeFee(from, change, expectedFeeRate, filter, options) {
        const feeRate = expectedFeeRate ??
            (await from.client.getFeeRate(options?.feeRateBlockRange, options));
        // Complete all inputs extra infos for cache
        await this.getInputsCapacity(from.client);
        let leastFee = index_js_3.Zero;
        let leastExtraCapacity = index_js_3.Zero;
        while (true) {
            const tx = this.clone();
            const collected = await (async () => {
                try {
                    return await tx.completeInputsByCapacity(from, leastFee + leastExtraCapacity, filter);
                }
                catch (err) {
                    if (leastExtraCapacity !== index_js_3.Zero) {
                        throw new Error("Not enough capacity for the change cell");
                    }
                    throw err;
                }
            })();
            await from.prepareTransaction(tx);
            if (leastFee === index_js_3.Zero) {
                // The initial fee is calculated based on prepared transaction
                leastFee = tx.estimateFee(feeRate);
            }
            const fee = await tx.getFee(from.client);
            // The extra capacity paid the fee without a change
            if (fee === leastFee) {
                this.copy(tx);
                return [collected, false];
            }
            const needed = (0, index_js_7.numFrom)(await Promise.resolve(change(tx, fee - leastFee)));
            // No enough extra capacity to create new cells for change
            if (needed > index_js_3.Zero) {
                leastExtraCapacity = needed;
                continue;
            }
            if ((await tx.getFee(from.client)) !== leastFee) {
                throw new Error("The change function doesn't use all available capacity");
            }
            // New change cells created, update the fee
            await from.prepareTransaction(tx);
            const changedFee = tx.estimateFee(feeRate);
            if (leastFee > changedFee) {
                throw new Error("The change function removed existed transaction data");
            }
            // The fee has been paid
            if (leastFee === changedFee) {
                this.copy(tx);
                return [collected, true];
            }
            // The fee after changing is more than the original fee
            leastFee = changedFee;
        }
    }
    completeFeeChangeToLock(from, change, feeRate, filter) {
        const script = script_js_1.Script.from(change);
        return this.completeFee(from, (tx, capacity) => {
            const changeCell = CellOutput.from({ capacity: 0, lock: script });
            const occupiedCapacity = (0, index_js_3.fixedPointFrom)(changeCell.occupiedSize);
            if (capacity < occupiedCapacity) {
                return occupiedCapacity;
            }
            changeCell.capacity = capacity;
            tx.addOutput(changeCell);
            return 0;
        }, feeRate, filter);
    }
    async completeFeeBy(from, feeRate, filter) {
        const { script } = await from.getRecommendedAddressObj();
        return this.completeFeeChangeToLock(from, script, feeRate, filter);
    }
    completeFeeChangeToOutput(from, index, feeRate, filter) {
        const change = Number((0, index_js_7.numFrom)(index));
        if (!this.outputs[change]) {
            throw new Error("Non-existed output to change");
        }
        return this.completeFee(from, (tx, capacity) => {
            tx.outputs[change].capacity += capacity;
            return 0;
        }, feeRate, filter);
    }
};
exports.Transaction = Transaction;
exports.Transaction = Transaction = Transaction_1 = __decorate([
    index_js_6.mol.codec(index_js_6.mol
        .table({
        raw: exports.RawTransaction,
        witnesses: index_js_6.mol.BytesVec,
    })
        .mapIn((txLike) => {
        const tx = Transaction.from(txLike);
        return {
            raw: tx,
            witnesses: tx.witnesses,
        };
    })
        .mapOut((tx) => Transaction.from({ ...tx.raw, witnesses: tx.witnesses })))
], Transaction);
/**
 * Calculate Nervos DAO profit between two blocks
 */
function calcDaoProfit(profitableCapacity, depositHeaderLike, withdrawHeaderLike) {
    const depositHeader = index_js_2.ClientBlockHeader.from(depositHeaderLike);
    const withdrawHeader = index_js_2.ClientBlockHeader.from(withdrawHeaderLike);
    const profitableSize = (0, index_js_7.numFrom)(profitableCapacity);
    return ((profitableSize * withdrawHeader.dao.ar) / depositHeader.dao.ar -
        profitableSize);
}
/**
 * Calculate claimable epoch for Nervos DAO withdrawal
 * See https://github.com/nervosnetwork/rfcs/blob/master/rfcs/0023-dao-deposit-withdraw/0023-dao-deposit-withdraw.md
 */
function calcDaoClaimEpoch(depositHeader, withdrawHeader) {
    const depositEpoch = index_js_2.ClientBlockHeader.from(depositHeader).epoch;
    const withdrawEpoch = index_js_2.ClientBlockHeader.from(withdrawHeader).epoch;
    const intDiff = withdrawEpoch[0] - depositEpoch[0];
    // deposit[1]    withdraw[1]
    // ---------- <= -----------
    // deposit[2]    withdraw[2]
    if (intDiff % (0, index_js_7.numFrom)(180) !== (0, index_js_7.numFrom)(0) ||
        depositEpoch[1] * withdrawEpoch[2] <= depositEpoch[2] * withdrawEpoch[1]) {
        return [
            depositEpoch[0] + (intDiff / (0, index_js_7.numFrom)(180) + (0, index_js_7.numFrom)(1)) * (0, index_js_7.numFrom)(180),
            depositEpoch[1],
            depositEpoch[2],
        ];
    }
    return [
        depositEpoch[0] + (intDiff / (0, index_js_7.numFrom)(180)) * (0, index_js_7.numFrom)(180),
        depositEpoch[1],
        depositEpoch[2],
    ];
}
