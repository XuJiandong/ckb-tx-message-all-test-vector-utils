import { BytesFromEncoding } from "./advanced.js";
/**
 * @public
 */
export type Bytes = Uint8Array;
/**
 * @public
 */
export declare const Bytes: Uint8ArrayConstructor;
/**
 * @public
 */
export type BytesLike = string | Uint8Array | ArrayBuffer | ArrayLike<number>;
/**
 * Concatenates multiple byte-like arrays to the first number array.
 * @public
 *
 * @param result - The number array as result
 * @param args - The byte-like arrays to concatenate.
 * @returns The first number array
 *
 * @example
 * ```typescript
 * const concatenatedBytes = [1, 2];
 * bytesConcatTo(
 *   concatenatedBytes
 *   new Uint8Array([3, 4]),
 *   "hello",
 *   [5, 6, 7]
 * );
 * console.log(concatenatedBytes); // Outputs [1, 2, 3, 4, /* bytes of "hello" *\/, 5, 6, 7]
 * ```
 */
export declare function bytesConcatTo(result: number[], ...args: BytesLike[]): number[];
/**
 * Concatenates multiple byte-like arrays into a single byte array.
 * @public
 *
 * @param args - The byte-like arrays to concatenate.
 * @returns A Uint8Array containing the concatenated bytes.
 *
 * @example
 * ```typescript
 * const concatenatedBytes = bytesConcat(
 *   new Uint8Array([1, 2]),
 *   new Uint8Array([3, 4]),
 *   "hello",
 *   [5, 6, 7]
 * );
 * console.log(concatenatedBytes); // Outputs Uint8Array [1, 2, 3, 4, /* bytes of "hello" *\/, 5, 6, 7]
 * ```
 */
export declare function bytesConcat(...args: BytesLike[]): Bytes;
/**
 * Converts a byte-like value to a string using the specified encoding.
 * @public
 *
 * @param val - The byte-like value to convert.
 * @param encoding - The encoding to use for the conversion, as defined by the BytesFromEncoding type.
 * @returns A string representing the encoded bytes.
 *
 * @example
 * ```typescript
 * const encodedString = bytesTo(new Uint8Array([104, 101, 108, 108, 111]), "utf8");
 * console.log(encodedString); // Outputs "hello"
 *
 * const base64String = bytesTo(new Uint8Array([104, 101, 108, 108, 111]), "base64");
 * console.log(base64String); // Outputs "aGVsbG8="
 * ```
 */
export declare function bytesTo(val: BytesLike, encoding: BytesFromEncoding): string;
/**
 * Converts various types of byte-like values to a Uint8Array.
 * @public
 *
 * @param bytes - The byte-like value to convert. It can be a string, Uint8Array, ArrayBuffer, or number array.
 * @param encoding - Optional encoding to use if the input is a string. Defaults to hexadecimal if not specified.
 * @returns A Uint8Array representing the input bytes.
 *
 * @throws Will throw an error if the input bytes are invalid or out of range.
 *
 * @example
 * ```typescript
 * const bytes1 = bytesFrom(new Uint8Array([1, 2, 3]));
 * console.log(bytes1); // Outputs Uint8Array [1, 2, 3]
 *
 * const bytes2 = bytesFrom("68656c6c6f", "hex");
 * console.log(bytes2); // Outputs Uint8Array [104, 101, 108, 108, 111]
 *
 * const bytes3 = bytesFrom("hello", "utf8");
 * console.log(bytes3); // Outputs Uint8Array [104, 101, 108, 108, 111]
 *
 * const bytes4 = bytesFrom([1, 2, 255]);
 * console.log(bytes4); // Outputs Uint8Array [1, 2, 255]
 * ```
 */
export declare function bytesFrom(bytes: BytesLike, encoding?: BytesFromEncoding): Bytes;
/**
 * Compares two byte-like values for equality.
 * @public
 *
 * @param a - The first byte-like value to compare.
 * @param b - The second byte-like value to compare.
 * @returns A boolean indicating whether the two byte-like values are equal.
 *
 * @example
 * ```typescript
 * bytesEq([1], Uint8Array.from([1])) // true
 * ```
 */
export declare function bytesEq(a: BytesLike, b: BytesLike): boolean;
//# sourceMappingURL=index.d.ts.map