pnpm build
pnpm pack
cp ckb-ccc-core-1.8.0.tgz ~/projects/ckb-tx-message-all-test-vector-utils/ccc-tests

